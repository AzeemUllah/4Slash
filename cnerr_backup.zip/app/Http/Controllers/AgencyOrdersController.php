<?php

namespace App\Http\Controllers;

use App\Order;
use Illuminate\Http\Request;
use App\Http\Requests;

use Illuminate\Support\Facades\Auth;

class AgencyOrdersController extends Controller
{
    public function getOrdersList(Request $request)
    {
        $agency = Auth::agency()->get();

        $orders = Order::where(['assigned_to' => $agency->id, 'status' => $request->input('status')])->get();

        $data['orders'] = $orders;

        return view('pages.agency.partials.orders_list')->with($data);
    }
}