<?php

namespace App;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

use Illuminate\Support\Facades\Auth;

class Order extends Model
{
    protected $table = 'orders';

    protected $fillable = [
        'uuid',
        'order_no',
        'gig_id',
        'gig_owner_id',
        'user_id',
        'company_name',
        'company_tagline',
        'company_industry',
        'company_discription',
        'company_email',
        'company_tel',
        'company_site',
        'company_extra_notes',
        'type',
        'amount',
        'expiry',
    ];

    public function acknowledge() {
        try {
            DB::transaction(function () {

                $this->status = 'complete';
                if ($this->save()) {

                    $invoice = new Invoice;
                    $invoice->generate($this->id);

                    $agency = User::where(['id' => $this->assigned_to])->first();
                    $agencyPercentAmount = (((double)$this->amount * (double)$agency->agency_percentage) / 100);
                    $agency->addWalletAmount($agencyPercentAmount);

                    $admin = User::where(['id' => $this->gig_owner_id])->first();
                    $adminPercentAmount = ((double)$this->amount - $agencyPercentAmount);
                    $admin->addWalletAmount($adminPercentAmount);

                    $gig = Gig::where(['id' => $this->gig_id])->first();

                    $agencyInvoice = new AgencyInvoice();
                    $agencyInvoice->setDetail($this->type . ": " . $gig->title . "\r\n" . "Order#: " . $this->order_no);
                    $agencyInvoice->setPayable($agencyPercentAmount);
                    $agencyInvoice->setBalance($agency->wallet);
                    $agencyInvoice->setAgencyId($agency->id);
                    $agencyInvoice->save();

                }


            });
        }catch(\Exception $e) {

        }

    }

    /**
     * @param string $compName
     * @param string $compEmail
     * @param string $compTel
     * @param string $compSite
     * @param string $compExNote
     *
     * @return bool
     */
    public static function createCustomOrder($request) {

        if($request->input('products')) {
            $products = implode(',', $request->input('products'));
        } else {
            $products = '';
        }
        $compName = $request->input('comp-name');
        $compEmail = $request->input('comp-email');
        $compTel = $request->input('comp-tel');
        $compSite = $request->input('comp-site');
        $compExNote = $request->input('comp-extra-note');

        try {

            DB::transaction(function () use ($products, $compName, $compEmail, $compTel, $compSite, $compExNote) {

                $order = new self();
                $order->uuid = \Webpatser\Uuid\Uuid::generate(4);
                $order->order_no = date("Ymd") . strtoupper(substr(uniqid(sha1(time())),0,4));
                $order->user_id = Auth::user()->get()->id;
                $order->company_name = $compName;
                $order->company_email = $compEmail;
                $order->company_tel = $compTel;
                $order->company_site = $compSite;
                $order->company_extra_notes = $compExNote;
                $order->custom_order_products = $products;
                $order->type = 'custom';
                $order->save();

                $admin = User::where(['type' => 'admin'])->first();

                Notification::sendNotification($admin->id, 'You have a new custom order.');

            });

            return true;

        } catch (\Exception $e) {

            return false;

        }

    }


}
