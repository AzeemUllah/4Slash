@extends('pages.admin.admin_template')


@section('header_title')

    <h1>Create a new Agency</h1>

@endsection




@section('content')

    <form method="post" action="{{ (($update) ? '' : route('adminagenciescreate') ) }}">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-info">

                    <div class="box-body">
                        <!-- text input -->
                        <div class="form-group<?= $errors->has('name') || $errors->has('username') ? ' has-error' : '' ?>">
                            <label>Agency Name</label>
                            <input name="name" type="text" value="{{ (($update) ? $agency->name : '') }}" class="form-control" placeholder="Enter Agency Name...">
                            @if($errors->has('name'))
                                <span class="help-block">{{ $errors->first('name') }}</span>
                            @endif
                            @if($errors->has('username'))
                                <span class="help-block">{{ $errors->first('username') }}</span>
                            @endif
                        </div>

                        <div class="form-group<?= $errors->has('email') ? ' has-error' : '' ?>">
                            <label>Agency Email</label>
                            <input name="email" type="email" value="{{ (($update) ? $agency->email : '') }}" class="form-control" placeholder="Enter Agency Email...">
                            @if($errors->has('email'))
                                <span class="help-block">{{ $errors->first('email') }}</span>
                            @endif
                        </div>

                        <div class="form-group<?= $errors->has('password') ? ' has-error' : '' ?>">
                            <label>Agency Password</label>
                            <input name="password" type="password" class="form-control" placeholder="Enter Agency Password...">
                            @if($errors->has('password'))
                                <span class="help-block">{{ $errors->first('password') }}</span>
                            @endif
                        </div>

                        <div class="input-group" style="width:150px;">
                            <input name="percent" type="number" value="{{ (($update) ? $agency->agency_percentage : '') }}" class="form-control">
                            <span class="input-group-addon">&#37;</span>
                        </div>

                        <div class="text-center">
                            @if(isset($update) && $update)
                                <button type="submit" class="btn btn-primary btn-lg" type="submit">Update and send Email</button>
                            @else
                                <button type="submit" class="btn btn-primary btn-lg" type="submit">Create and send Email</button>
                            @endif
                        </div>

                    </div>
                </div>
            </div>
        </div>




    </form>

@endsection



@section('pages_css')

    <link rel="stylesheet" href="{{ asset('bower_components/AdminLTE/plugins/select2/select2.min.css') }}">

@endsection



@section('pages_script')

    <script src="{{ asset('bower_components/AdminLTE/plugins/select2/select2.full.min.js') }}"></script>

@endsection