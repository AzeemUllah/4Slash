<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
Route::get('/activate/email', [
    'uses' => 'AuthController@activateEmail',
    'as' => 'user.email.activate'
]);

Route::get('/', ['as' => 'index', 'uses' => 'HomeController@index']);

Route::get('/logout', 'AuthController@getLogout');

Route::get('/google_login', 'AuthController@redirectToGoogleProvider');

Route::get('/google_callback', 'AuthController@handleGoogleProviderCallback');

Route::get('/login', [
    'uses' => 'LoginController@index',
    'as' => 'getLogin'
]);

Route::get('/register', [
    'uses' => 'RegisterController@index'
]);

Route::post('register', [
    'uses' => 'RegisterController@postRegister',
    'as' => 'create.user.account'
]);


Route::get('/gigs', [
    'uses' => 'GigsController@index',
    'as' => 'gigs',
]);

Route::get('/gigs/{categoryslug}', [
    'uses' => 'GigsController@getGigsByCategory',
    'as' => 'gigscategory.gigs'
]);

Route::get('/gigs/cat/{categoryslug}/subcat/{subcategoryslug}', [
    'uses' => 'GigsController@getGigsBySubCategory',
    'as' => 'category.subcategory.gigs'
]);



// Password reset link request routes...
Route::get('password/email', 'Auth\PasswordController@getEmail');
Route::post('password/email', 'Auth\PasswordController@postEmail');

// Password reset routes...
Route::get('password/reset/{token}', 'Auth\PasswordController@getReset');
Route::post('password/reset', 'Auth\PasswordController@postReset');




/*
 * Restricted Pages
 */

Route::get('/notifications', ['middleware' => 'auth', 'uses' => 'NotificationsController@index']);
Route::get('/profile', [
    'middleware' => 'auth',
    'uses' => 'ProfileController@index',
    'as' => 'profile'
]);
Route::post('/profile/change-profile-image', [
    'middleware' => 'auth',
    'uses' => 'ProfileController@change_profile_image',
    'as' => 'changeprofileimage',
]);
Route::post('/profile/change-profile-cover-image', [
    'middleware' => 'auth',
    'uses' => 'ProfileController@change_profile_cover_image',
    'as' => 'changeprofilecoverimage',
]);
Route::get('/payments', ['middleware' => 'auth', 'uses' => 'PaymentsController@index']);
Route::get('/settings', [
    'middleware' => 'auth',
    'uses' => 'SettingsController@index',
    'as' => 'mysettings',
]);

Route::get('/gigs/{gigType}', ['middleware' => 'auth', 'uses' => 'GigsController@gigsByType']);
Route::get('/gigs/{gigType}/{gig}', ['uses' => 'GigController@index']);
Route::post('/gigs/{gigType}/{gig}', ['uses' => 'GigController@index']);
Route::post('/gigs/{gigType}/{gig}/order', ['middleware' => 'auth', 'uses' => 'OrderController@index']);

Route::get('/order/commitorder', ['middleware' => 'auth', 'uses' => 'OrderController@createOrder', 'as' => 'ordercommit']);







Route::post('login', ['uses' => 'AuthController@postLogin', 'as' => 'login']);




Route::get('/order/{orderno}/invoice/{invoiceno}', [
    'uses' => 'InvoiceController@index',
    'as' => 'orderinvoice',
]);





Route::get('payment/status', [
    'as' => 'payment.status',
    'uses' => 'PaypalController@getPaymentStatus',
]);

Route::get('/packages', [
    'uses' => 'PackagesController@index',
    'as' => 'userpackages'
]);







Route::group(['middleware' => 'auth'], function() {

    Route::get('/dashboard', [
        'uses' => 'DashboardController@index',
        'as' => 'dashboard'
    ]);

    Route::get('/favourites', [
        'uses' => 'MyFavouritesController@index',
        'as' => 'myfavourites',
    ]);

    Route::post('/customorder/create', [
        'uses' => 'CustomOrdersController@create',
        'as' => 'customordercreate'
    ]);

    Route::get('/my_orders', [
        'uses' => 'MyOrdersController@index',
        'as' => 'myorders'
    ]);

    Route::get('/order/{orderno}', [
        'uses' => 'MyOrdersController@getMyOrder',
        'as' => 'getmyorder'
    ]);

    Route::post('/order/message', [
        'uses' => 'MyOrdersController@postMessage',
        'as' => 'order.post.message'
    ]);

    Route::post('/order/acknowledge', [
        'uses' => 'MyOrdersController@orderAcknowledge',
        'as' => 'order.acknowledge'
    ]);

    Route::post('/order/askformodification', [
        'uses' => 'MyOrdersController@orderAskForModification',
        'as' => 'order.askformodification'
    ]);

    Route::post('/order/custom/create', [
        'uses' => 'OrderController@createCustomOrder',
        'as' => 'order.custom.create'
    ]);

    Route::get('/order/package/create', [
        'uses' => 'OrderController@createPackageOrder',
        'as' => 'order.package'
    ]);

    Route::get('/confirmorder/{orderType}', [
        'uses' => 'OrderController@confirmOrder',
        'as' => 'order.confirm'
    ]);

    Route::get('/payment', [
        'uses' => 'PaypalController@postPaymentWithoutLogin',
        'as' => 'payment',
    ]);



    Route::post('/gig/favourite', [
        'uses' => 'GigController@favourite',
        'as' => 'gig.favourite'
    ]);


});

Route::post('/payment', [
    'uses' => 'PaypalController@postPayment',
    'as' => 'payment'
]);



























Route::group(['prefix' => '/admin'], function() {

    Route::get('/', function () {
        return redirect()->route('adminlogin');
    });

    Route::get('/login', ['uses' => 'AdminLoginController@index', 'as' => 'adminlogin']);

    Route::post('/login', ['uses' => 'AdminAuthController@postLogin', 'as' => 'adminpostlogin']);

    Route::group(['middleware' => 'auth.admin'], function() {

        Route::get('/packages', [
            'uses' => 'PackagesController@index',
            'as' => 'adminpackages',
        ]);

        Route::get('/packages/create', [
            'uses' => 'AdminPackagesController@create',
            'as' => 'adminpackagescreate'
        ]);

        Route::post('/packages/create', [
            'uses' => 'AdminPackagesController@create'
        ]);

        Route::get('/packages/types', [
            'uses' => 'AdminPackagesTypesController@index',
            'as' => 'adminpackagestypes'
        ]);

        Route::get('/packages/types/create', [
            'uses' => 'AdminPackagesTypesController@create',
            'as' => 'adminpackagestypescreate'
        ]);

        Route::post('/packages/types/create', [
            'uses' => 'AdminPackagesTypesController@create'
        ]);

        Route::post('/packages/types/delete', [
            'uses' => 'AdminPackagesTypesController@delete',
            'as' => 'adminpackagestypesdelete'
        ]);

        Route::get('/gigs', [
            'uses' => 'AdminGigsController@index',
            'as' => 'admingigs',
        ]);

        Route::get('/notifications', [
            'uses' => 'NotificationsController@getNotifications',
            'as' => 'getnotifications'
        ]);

        Route::get('/packages', [
            'uses' => 'AdminPackagesController@index',
            'as' => 'adminpackages',
        ]);

        Route::get('/gigs/create', [
            'uses' => 'AdminGigsController@create',
            'as' => 'gigcreate'
        ]);

        Route::post('/gig/update', [
            'uses' => 'AdminGigController@update',
            'as' => 'gig.update'
        ]);

        Route::post('/gigs/create', 'AdminGigsController@createGig');

        Route::delete('/gigs/delete', [
            'uses' => 'AdminGigsController@deleteGig',
            'as' => 'adminGigDelete'
        ]);

        Route::get('/gigs/categories', [
            'uses' => 'AdminGigsCategoriesController@index',
            'as' => 'admingigscategories'
        ]);

        Route::get('/gigs/category/subcategories', [
            'uses' => 'AdminGigsCategoriesController@getSubCategories',
            'as' => 'admin.category.subcategories'
        ]);

        Route::get('/gigs/categories/create', [
            'uses' => 'AdminGigsCategoriesController@getCreate',
            'as' => 'admingigscategoriescreate'
        ]);

        Route::post('/gigs/categories/create', [
            'uses' => 'AdminGigsCategoriesController@postCreate',
            'as' => 'admingigscategoriescreatecreate'
        ]);

        Route::post('/gigs/categories/update', [
            'uses' => 'AdminGigsCategoriesController@categoryUpdate',
            'as' => 'gigs.categories.update'
        ]);

        Route::post('/gigs/categories/delete', [
            'uses' => 'AdminGigsCategoriesCreateController@delete',
            'as' => 'admingigscategoriesdelete'
        ]);

        Route::post('/gig/image/{imageid}/remove', [
            'uses' => 'AdminGigController@removeGigImage',
            'as' => 'gig.image.remove'
        ]);

        Route::post('/gig/activate', [
            'uses' => 'AdminGigController@gigActivate',
            'as' => 'gig.activate'
        ]);

        Route::post('/gig/featured', [
            'uses' => 'AdminGigController@gigFeatured',
            'as' => 'gig.featured'
        ]);

        Route::get('/dashboard', [
            'uses' => 'AdminDashboardController@index',
            'as' => 'admindashboard',
        ]);

        Route::get('/agencies', [
            'uses' => 'AdminAgenciesController@index',
            'as' => 'adminagencies',
        ]);

        Route::get('/agency/{agencyEmail}', [
            'uses' => 'AdminAgenciesController@getAgency',
            'as' => 'admin.agency'
        ]);

        Route::get('/orders', [
            'uses' => 'AdminOrdersController@index',
            'as' => 'adminorders',
        ]);

        Route::get('/orders/custom', [
            'uses' => 'AdminOrdersController@customOrders',
            'as' => 'admin.orders.custom'
        ]);

        Route::get('/orders/packages', [
            'uses' => 'AdminOrdersController@packagesOrders',
            'as' => 'admin.orders.packages'
        ]);

        Route::post('/order/assign', [
            'uses' => 'AdminOrderController@assignJobTo',
            'as' => 'adminorderassign'
        ]);

        Route::get('/order/{orderno}/{orderuuid}', [
            'uses' => 'AdminOrderController@index',
            'as' => 'adminorder',
        ]);

        Route::get('/order/{orderno}/{orderuuid}/jobdone', [
            'uses' => 'AdminOrderController@jobDone',
            'as' => 'adminorderjobdone',
        ]);

        Route::post('/order/{orderno}/{orderuuid}', [
            'uses' => 'AdminOrderController@sendOrderMessage',
            'as' => 'adminordermessage'
        ]);

        Route::get('/agencies/create', [
            'uses' => 'AdminAgenciesCreateController@index',
            'as' => 'adminagenciescreate',
        ]);

        Route::post('/agencies/create', [
            'uses' => 'AdminAgenciesCreateController@agencyRegister',
        ]);

        Route::get('/agencies/{agencyEmail}/update', [
            'uses' => 'AdminAgenciesController@agencyUpdate',
            'as' => 'agency.update'
        ]);

        Route::post('/agencies/{agencyEmail}/update', [
            'uses' => 'AdminAgenciesController@putAgencyUpdate',
            'as' => 'agency.put.update'
        ]);

        Route::post('/agencies/amount/withdraw', [
            'uses' => 'AdminAgenciesController@withdrawAgencyAmount',
            'as' => 'agency.amount.withdraw'
        ]);

        Route::get('/logout', [
            'uses' => 'AdminAuthController@logout',
            'as' => 'adminlogout'
        ]);



    });


});

Route::group(['prefix' => '/agency'], function() {

    Route::get('/login', [
        'uses' => 'AgencyAuthController@index',
        'as' => 'agencylogin'
    ]);

    Route::post('/login',[
        'uses' => 'AgencyAuthController@postLogin',
        'as' => 'agencypostlogin'
    ]);

    Route::group(['middleware' => 'auth.agency'], function() {

        Route::get('/dashboard', [
            'uses' => 'AgencyDashboardController@index',
            'as' => 'agencydashboard'
        ]);

        Route::get('/orders-list', [
            'uses' => 'AgencyOrdersController@getOrdersList',
            'as' => 'agencyorderslist'
        ]);

        Route::get('/order', [
            'uses' => 'AgencyOrderController@index',
            'as' => 'agencyorder'
        ]);

        Route::post('/order/sendmessage', [
            'uses' => 'AgencyOrderController@sendOrderMessage',
            'as' => 'agencyordermessage'
        ]);

    });

});









/*
 * Authentication
 */

//Route::get('register', ['uses' => 'AuthController@getRegister', 'as' => 'auth.reg']);
//Route::post('register', ['uses' => 'AuthController@postRegister']);




/*
 * Web Services API
 */

Route::group(['prefix' => 'api'], function() {
    Route::resource('authenticate', 'AuthenticateController', ['only' => ['index']]);
    Route::post('authenticate', 'AuthenticateController@authenticate');

    Route::get('authenticate/google', 'AuthenticateController@redirectToGoogleProvider');
    Route::get('authenticate/google/callback', 'AuthenticateController@handleGoogleProviderCallback');
});
