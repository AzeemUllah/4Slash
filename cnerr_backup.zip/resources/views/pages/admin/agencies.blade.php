@extends('pages.admin.admin_template')


@section('header_title')

    <h1>Agencies</h1>

@endsection




@section('content')
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header text-right">
                    <a href="{{ route('adminagenciescreate') }}" class="btn btn-primary btn-sm"><span class="fa fa-plus"></span></a>
                </div><!-- /.box-header -->
                <div class="box-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Percentage</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($agencies as $agency)
                            <tr>
                                <td>{{ $agency->name }}</td>
                                <td>{{ $agency->email }}</td>
                                <td>{{ $agency->agency_percentage }}%</td>
                                <td>
                                    {{--<button class="btn btn-primary btn-xs"><span class="fa fa-edit"></span></button>--}}
                                    <a href="{{ route('admin.agency', ['agencyEmail' => $agency->email]) }}" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-eye-open"></span></a>
                                    <a href="{{ route('agency.update', ['agencyEmail' => $agency->email]) }}" class="btn btn-default btn-xs"><span class="fa fa-pencil"></span></a>
                                    <button class="btn btn-danger btn-xs btn-del"><span class="fa fa-trash-o"></span></button>
                                </td>
                            </tr>
                        @endforeach

                        </tbody>

                    </table>
                </div><!-- /.box-body -->
            </div><!-- /.box -->
        </div><!-- /.col -->
    </div><!-- /.row -->
    @endsection




    @section('pages_css')

            <!-- DataTables -->
    <link rel="stylesheet" href="{{ asset('bower_components/AdminLTE/plugins/datatables/dataTables.bootstrap.css') }}">

    @endsection





    @section('pages_script')

            <!-- DataTables -->
    <script src="{{ asset('bower_components/AdminLTE/plugins/datatables/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('bower_components/AdminLTE/plugins/datatables/dataTables.bootstrap.min.js') }}"></script>
    <!-- page script -->
    <script>
        $(function () {
            var table = $("#example1").DataTable();

            $('#example1 tbody').on('click', 'button.btn-del', function() {

                table.row( $(this).parents('tr') ).remove().draw();

            });

        });
    </script>

@endsection