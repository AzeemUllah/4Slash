<?php

namespace App\Http\Controllers;


use App\Notification;

class NotificationsController extends Controller
{
    public function index()
    {

    }

    public function getNotifications()
    {
        $notifications = Notification::getNotifications();

        return $notifications;
    }

}
