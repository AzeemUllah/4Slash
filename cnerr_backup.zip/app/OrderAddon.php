<?php

namespace App;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class OrderAddon extends Model
{
    protected $table = 'order_addons';

    protected $fillable = [
        'addon_id',
        'quantity',
        'total_amount',
        'order_id'
    ];

    public $addon;
    public $amount;

    public static function getOrderAddons($addons) {
        $orderAddons = [];

        if(is_array($addons)) {
            foreach ($addons as $key => $value) {
                $gigAddon = Gig_addon::where('id', $key)->first();

                $orderAddon = new OrderAddon();
                $orderAddon->addon = $gigAddon->addon;
                $orderAddon->addon_id = $key;
                $orderAddon->amount = $gigAddon->amount;
                $orderAddon->quantity = $value;
                $orderAddon->total_amount = ((float)$gigAddon->amount * (float)$value);

                array_push($orderAddons, $orderAddon);
            }
        }

        return $orderAddons;
    }
}