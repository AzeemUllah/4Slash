<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;

use App\Order;
use Illuminate\Support\Facades\Auth;

class AgencyDashboardController extends Controller
{
    public function index(Request $request)
    {
        $agency = Auth::agency()->get();

        $orders = Order::where(['assigned_to' => $agency->id, 'status' => 'pending'])->get();

        $data['orders'] = $orders;

        return view('pages.agency.dashboard')->with($data);
    }
}