<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        <!-- Sidebar user panel (optional) -->
        <div class="user-panel">
            <div class="pull-left image">
                @if(!empty(\Illuminate\Support\Facades\Auth::admin()->get()->profile_image))
                    <img src="{{ \Illuminate\Support\Facades\Auth::admin()->get()->profile_image }}" class="img-circle" alt="User Image">
                @else
                    <div class="img-circle" style="font-size:30px;color:white;width:45px;height:45px;background-color: gray;text-align:center;">{{ \Illuminate\Support\Facades\Auth::admin()->get()->username[0] }}</div>
                @endif
            </div>
            <div class="pull-left info">
                <p>{{ \Illuminate\Support\Facades\Auth::admin()->get()->username }}</p>
                <!-- Status -->
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>



        <!-- Sidebar Menu -->
        <ul class="sidebar-menu">
            <li class="header">MAIN MENU</li>
            <!-- Optionally, you can add icons to the links -->
            <li class="active">
                <a href="{{ route('admindashboard') }}"><span>Dashboard</span></a>
            </li>

            <li class="treeview">
                <a href="#"><span>Gigs</span> <i class="fa fa-angle-left pull-right"></i></a>
                <ul class="treeview-menu">
                    <li><a href="{{ route('admingigs') }}">All Gigs</a></li>
                    <li><a href="{{ route('admingigscategories') }}">Categories</a></li>
                </ul>
            </li>

            <li class="treeview">
                <a href="#"><span>Packages</span> <i class="fa fa-angle-left pull-right"></i></a>
                <ul class="treeview-menu">
                    <li><a href=" {{ route('adminpackages') }}">All Packages</a></li>
                    <li><a href="{{ route('adminpackagestypes') }}">Package Types</a></li>
                </ul>
            </li>

            <li>
                <a href="{{ route('adminagencies') }}"><span>Agencies</span></a>
            </li>


            <li class="treeview">
                <a href="#">
                    Orders
                    <i class="fa fa-angle-left pull-right"></i>
                </a>

                <ul class="treeview-menu">
                    <li class="treeview">
                        <a href="#">
                            Gig Orders
                            <i class="fa fa-angle-left pull-right"></i>
                        </a>

                        <ul class="treeview-menu">
                            <li>
                                <a href="{{ route('adminorders') }}?status=pending">
                                    Pending Orders
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('adminorders') }}?status=complete">
                                    Completed Orders
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="treeview">
                        <a href="#">
                            Custom Orders
                            <i class="fa fa-angle-left pull-right"></i>
                        </a>

                        <ul class="treeview-menu">
                            <li>
                                <a href="{{ route('admin.orders.custom') }}?status=pending">
                                    Pending Orders
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('admin.orders.custom') }}?status=complete">
                                    Completed Orders
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="treeview">
                        <a href="#">
                            Package Orders
                            <i class="fa fa-angle-left pull-right"></i>
                        </a>

                        <ul class="treeview-menu">
                            <li>
                                <a href="{{ route('admin.orders.packages') }}?status=pending">
                                    Pending Orders
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('admin.orders.packages') }}?status=complete">
                                    Completed Orders
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li>
                <a href="{{ url() }}" target="_blank">Visit Cnerr</a>
            </li>
            <li>
                <a href="{{ route('adminlogout') }}">Log Out</a>
            </li>


        </ul><!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>