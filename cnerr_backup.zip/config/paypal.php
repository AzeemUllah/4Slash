<?php
return [

    'client_id' => 'AW-vwgCeMFm-EtHFvVxDugwMapGSvF4jp3tmqcXwBBQXl5tmaDZRDWzCxr5ej5sOS1bwA0eyCy_oJMXW',
    'secret' => 'EI30qHLfj-qHO07EsyD--Y861GeggLppvTSt4kZt2tsDtndXRp0AVpMnN3By1TgvJGpgyQlRt-ZARNU1',
    'settings' => [
        /**
         * Available option 'sandbox' or 'live'
         */
        'mode' => 'sandbox',

        /**
         * Specify the max request time in seconds
         */
        'http.ConnectionTimeOut' => 30,

        'log.LogEnabled' => true,

        'log.FileName' => storage_path() . '/logs/paypal.log',

        /**
         * Available option 'FINE', 'INFO', 'WARN' or 'ERROR'
         *
         * Logging is most verbose in the 'FINE' level and decreases as you
         * proceed towards ERROR
         */
        'log.LogLevel' => 'FINE'
    ],
];