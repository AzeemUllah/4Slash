<header class="main-header">

    <div class="mp-box mp-box-trans">
        <div class="box-row">
            <a href="/" class="logo js-gtm-event" data-gtm-action="logo" data-gtm-event="navigation" data-gtm-label="clicked">Cnerr logo</a>


            <nav class="global-search-box top-nav-search">
                <div class="inner cf">


                    <form accept-charset="UTF-8" action="{{ route('gigs') }}" id="search-form-nav-bar" method="get">


                        <div class="global-search js-global-search">
                            <input class="js-search-input" id="" maxlength="40" name="search" placeholder="Dienstleistungen suchen" type="text" autocomplete="off">
                            <button style="border:0px;" type="submit" class="js-search-submit magnify"></button>
                        </div>

                    </form>

                </div>
            </nav>


            <script type="text/javascript">
            </script>

            @if(\Illuminate\Support\Facades\Auth::user()->check())
                <nav class="main-nav main-nav-user">
                    <ul>


                        <li class="menu-icn icn-todo hint--bottom js-mark" data-mark="todos" data-hint="Dashboard">
                            <a href="{{ route('dashboard') }}" class="js-gtm-event-auto" data-gtm-action="black-nav-loggedin" data-gtm-category="navigation" data-gtm-label="to do"></a>
                        </li>


                        {{--<li class="dropdown header-notify menu-icn icn-notify hint--bottom js-mark" data-mark="notifications" data-hint="Notifications">--}}
                            {{--<a href="#" data-toggle="dropdown" class="js-notify-trigger js-gtm-event-auto" data-gtm-category="navigation" data-gtm-action="black-nav-loggedin" data-gtm-label="open notifications" rel="noindex, nofollow"></a>--}}
                            {{--<div class="notify-menu">--}}
                                {{--<header>--}}
                                    {{--<h6>--}}
                                        {{--<a class="mark-read js-mark-read js-gtm-event-auto" href="#" data-gtm-category="navigation" data-gtm-action="black-nav-loggedin" data-gtm-label="mark notifications" rel="noindex, nofollow">Mark all as read</a>--}}
                                        {{--Notifications--}}
                                    {{--</h6>--}}
                                {{--</header>--}}
                                {{--<div class="antiscroll-wrap">--}}
                                    {{--<div class="antiscroll-inner">--}}
                                        {{--<ul class="loading"></ul>--}}
                                        {{--<a class="load-more js-load-more js-gtm-event-auto" href="#" data-gtm-category="navigation" data-gtm-action="black-nav-loggedin" data-gtm-label="load notifications" rel="noindex, nofollow">Load More</a>--}}
                                    {{--</div>--}}
                                {{--</div>--}}
                            {{--</div>--}}

                        {{--</li>--}}

                        <li class="menu-icn icn-inbox hint--bottom js-icn-inbox js-mark marked" data-mark="inbox" data-hint="Workstreams">
                            <a href="{{ route('myorders') }}" class="js-gtm-event-auto" data-gtm-action="black-nav-loggedin" data-gtm-category="navigation" data-gtm-label="click conversations"></a>
                        </li>


                        <li class="dropdown-container header-user header-user-is-online">
                            <a href="{{ route('dashboard') }}" class="user-trigger js-gtm-event-auto" data-gtm-action="black-nav-loggedin" data-gtm-category="navigation" data-gtm-label="open username">
                                <span class="user-pict-24"><img src="{{ \Illuminate\Support\Facades\Auth::user()->get()->profile_image }}" alt="zohaibghafoor2" width="24" height="24" data-reload="inprogress"></span>
                                <span class="user-is-online  is-online" data-user-id="zohaibghafoor2"><em></em></span>

                                <span class="user-name">{{ \Illuminate\Support\Facades\Auth::user()->get()->username }}</span>
                            </a>

                            <div class="dropdown">
                                <ul>
                                    <li>
                                        <a href="{{ url() }}/dashboard"><span class="fa fa-tachometer"></span> Dashboard</a>
                                    </li>
                                    <li>
                                        <a href="{{ url() }}/profile"><span class="glyphicon glyphicon-user"></span> Mein Profil</a>
                                    </li>
                                    <li>
                                        <a href="{{ route('myorders')  }}"><span class="glyphicon glyphicon-list"></span> Bestellungen</a>
                                    </li>

                                    <li>
                                        <a href="{{ url() }}/payments"><span class="glyphicon glyphicon-credit-card"></span> Zahlungen</a>
                                    </li>

                                    <li>
                                        <a href="{{ route('myfavourites') }}"><span class="glyphicon glyphicon-heart"></span> Favoriten</a>
                                    </li>
                                    <li>
                                        <a href="{{ url() }}/settings"><span class="glyphicon glyphicon-cog"></span> Einstellungen
</a>
                                    </li>



                                    <li class="divi">&nbsp;</li>
                                    <li>
                                        <a href="{{ url() }}/logout"><span class="glyphicon glyphicon-off"></span>Abmelden</a>
                                    </li>
                                </ul>
                            </div>
                        </li>


                    </ul>
                </nav>
            @else
                <nav class="main-nav main-nav-guest">
                    <ul>
                        <li><a href="#" class="js-open-popup-join js-gtm-event" data-gtm-action="black-nav" data-gtm-label="join" data-gtm-event="navigation" data-toggle="modal" data-target="#gridSystemModal1">Registrieren</a></li>
                        <li><a href="#" class="js-open-popup-login js-gtm-event" data-gtm-action="black-nav" data-gtm-label="sign in" data-gtm-event="navigation" data-toggle="modal" data-target="#gridSystemModal">Anmelden</a></li>
                    </ul>
                </nav>
            @endif


        </div>
    </div>

    <div class="mp-box mp-box-white notop mp-cat-list-curated js-cat-list-curated">
        <div class="box-row">
            <ul class="main-cat-list js-main-cat-list active">

                @foreach(\App\Gigtype::all() as $cat)
                    <li class="">
                    <a href="/gigs/{{ $cat->slug }}" data-gtm-action="homepage-dropdown-click" data-gtm-event="Category Navigation" data-gtm-label="graphics-design" data-title="Graphics &amp; Design">{{ $cat->name }}</a>
                    <div class="unnecessary-firefox-wrapper">
                        @if(count(\App\Gigtype_Subcategory::where(['gigtypes_id' => $cat->id])->get()) > 0)
                            <div class="menu-cont">
                                <ul>
                                    @foreach(\App\Gigtype_Subcategory::where(['gigtypes_id' => $cat->id])->get() as $subcat)
                                        <li><a href="{{ route('category.subcategory.gigs', ['categoryslug' => $cat->slug, 'subcategoryslug' => $subcat->slug]) }}" data-gtm-action="homepage-dropdown-click" data-gtm-event="Category Navigation" data-gtm-label="create-cartoon-caricatures" data-title="Cartoons &amp; Caricatures">{{ $subcat->name }}</a></li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif
                    </div>
                </li>
                @endforeach
                <li class="cat-wide align-right"><a href="/categories/lifestyle" data-gtm-action="homepage-dropdown-click" data-gtm-event="Category Navigation" data-gtm-label="lifestyle" data-title="Lifestyle">Lifestyle</a></li>
                <li class="cat-wide align-right"><a href="/categories/gifts" data-gtm-action="homepage-dropdown-click" data-gtm-event="Category Navigation" data-gtm-label="gifts" data-title="Gifts">Gifts</a></li>
                <li class="cat-wide align-right"><a href="/categories/fun-bizarre" data-gtm-action="homepage-dropdown-click" data-gtm-event="Category Navigation" data-gtm-label="fun-bizarre" data-title="Fun &amp; Bizarre">Fun &amp; Bizarre</a></li>
                <li class="cat-wide align-right"><a href="/categories/other" data-gtm-action="homepage-dropdown-click" data-gtm-event="Category Navigation" data-gtm-label="other" data-title="Other">Other</a></li>


            </ul>
        </div>
    </div>

        <div class="custom-gigs" style="margin:0px;">
            <div class="container">
                <div class="col-md-7 toggle-pane" style="border:2px solid #008fd5; background-color:white; position:absolute; right:120px; z-index:1000;">
                    <div class="gig-style">
                        <form id="formCustomOrder" method="post" action="{{ route('order.custom.create') }}">
                            <div class="col-md-5">
                                <h4 style="font-size:20px; font-family:Raleway-Medium; color:#008fd5">Produkte</h4>
                                <?php $count = 1; ?>
                                @foreach(\App\Gigtype::all() as $cat)
                                    <div class="accordion-group new-accordion">
                                    <div class="accordion-heading">
                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse{{ $count }}">
                                            {{ $cat->name }}
                                        </a>
                                    </div>

                                    <div id="collapse{{ $count }}" class="accordion-body collapse {{ (($count == 1)) ?  : ''}}">
                                        <div class="accordion-inner">
                                            <?php $subCatCount = 1; ?>
                                            @foreach(\App\Gigtype_Subcategory::where(['gigtypes_id' => $cat->id])->get() as $subCat)
                                                <div class="checkbox checkbox-info checkbox-circle chck-bx3">
                                                <input value="{{ $subCat->name }}" name="products[]" id="checkbox{{ $count . $subCatCount }}" class="styled" type="checkbox">
                                                <label for="checkbox{{ $count . $subCatCount }}">
                                                    <p class="chck-bx-p">{{ $subCat->name }}</p>
                                                </label>
                                            </div>
                                                <?php $subCatCount++ ?>
                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                                    <?php $count++; ?>
                                @endforeach
                            </div>

                            <div class="col-md-7 sub-form">
                                    <h4>Kundeninformationen</h4>
                                    <input required name="comp-name" type="text" class="form-control input-lg" placeholder="Name">
                                    <input required name="comp-email" type="email" class="form-control input-lg" placeholder="E-mail">
                                    <input required name="comp-tel" type="tel" class="form-control input-lg" placeholder="Telefon
">
                                    <input required name="comp-site" type="text" class="form-control input-lg" placeholder="Website">
                                    <textarea required name="comp-extra-note" class="form-control" placeholder="Bemerkung" rows="4"></textarea>
                                    <p style="font-size:14px; color:#7b7b7b;">Wann soll geliefert werden ?
</p>
                                    <input class="form-control input-lg" placeholder="Wunsch-Liefertermin
">
                                    <button type="submit" class="btn btn-primary form-btn">senden</button>

                            </div>
                        </form>
                    </div>
                    <a href="{{ route('userpackages') }}" class="btn btn-primary btn-packages" style="right: 235px;color:white; font-size:16px; font-family:HelveticaLTStd-Light; outline:none;">Pakete</a>
                    <button type="button" class="btn btn-primary btn-custom-gig" style="color:white; font-size:16px; font-family:HelveticaLTStd-Light; outline:none;">Individuelle Anfrage <span class="glyphicon glyphicon-menu-down"></span></button>
                </div>
            </div>
        </div>


    <div class="modal fade" role="dialog" aria-labelledby="gridSystemModalLabel" id="gridSystemModal1" tabindex="-1" >
        <div class="modal-dialog modal-sm model-login-width" role="document">
            <div class="modal-content" ng-controller="RegisterController">
                <div class="modal-header login-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title login-title" id="gridSystemModalLabel">Registrierung</h4>
                </div>
                <div class="modal-body">
                    <div class="container-fluid">
                        <form>
                            <div class="username form-group<?= "{{ hasEmailError ? ' has-error' : '' }}" ?>">
                                <label for="email_adress" class="sr-only">Email_address</label>
                                   <span style="position:relative; top:38px; left:10px;">
                                        <i class="fa fa-envelope-o"></i>
                                    </span>
                                <input ng-model="emailModel" type="email" class="form-control em" id="email_adress" placeholder="E-mail" style="height:50px; padding: 6px 45px;">
                                <p class="help-block"><?='{{  email }}'?></p>
                            </div>
                            <div class="user form-group<?= "{{ hasUsernameError ? ' has-error' : '' }}" ?>">
                                <label for="user" class="sr-only">User Name</label>
                                   <span style="position:relative; top:38px; left:10px;">
                                        <img src="img/lg-men.png" style="height:25px;">
                                    </span>
                                <input ng-model="usernameModel" type="text" class="form-control em" id="user" placeholder="Benutzername" style="height:50px; padding: 6px 45px;">
                                <p class="help-block"><?="{{  username }}"?></p>
                            </div>
                            <div class="pass form-group<?= "{{ hasPasswordError ? ' has-error' : '' }}" ?>">
                                <label for="pass" class="sr-only">Password</label>
                                   <span style="position:relative; top:40px; left:10px;">
                                        <img src="img/lg-key.png" style="height:25px;">
                                    </span>
                                <input ng-model="passwordModel" type="password" class="form-control em" id="Pass" placeholder="passwort" style="height:50px; padding: 6px 45px;">
                                <p class="help-block"><?='{{  password }}'?></p>
                            </div>
                            <div class="con_pass form-group">
                                <label for="con_pass" class="sr-only">Confirm Password</label>
                                   <span style="position:relative; top:40px; left:10px;">
                                        <img src="img/lg-key.png" style="height:25px;">
                                    </span>
                                <input ng-model="passwordConfirmationModel" type="password" class="form-control em" id="con_pass" placeholder="
Bestätige das Passwort" style="height:50px; padding: 6px 45px;">
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="chk-margin-float">
                                    </div>
                                </div><!-- /.col-lg-6 -->
                                <div class="col-lg-6">
                                    <div class="btn-margin-float">
                                        <input type="submit" class="btn btn-primary" value="Registrierung" ng-disabled="regSubmitted" ng-click="register()">
                                    </div>
                                </div><!-- /.col-lg-6 -->
                            </div><!-- /.row -->
                        </form>
                    </div>
                </div>
                <div class="modal-footer login-footer">
                    <p class="footer-p">Sind sie bereits registriert? Klicken Sie <a href="#">hier</a> um sich einzuloggen</p>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
















    <div class="modal fade" role="dialog" aria-labelledby="gridSystemModalLabel" id="gridSystemModal" tabindex="-1" >
        <div class="modal-dialog modal-sm model-login-width" role="document">
            <div class="modal-content" ng-controller="LoginController">
                <div class="modal-header login-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title login-title" id="gridSystemModalLabel">Kundenlogin</h4>
                </div>


                <div ng-if="hasOtherError" class="alert alert-danger animate-if" role="alert">
                    <span class="glyphicon glyphicon-warning-sign"></span>
                    <?php echo "{{ other }}" ?>
                </div>


                <div class="modal-body">
                    <form>
                        <div class="input form-group<?= "{{ hasEmailError ? ' has-error' : '' }}" ?>" style="positon:relative">
                            <label for="emailadress" class="sr-only">Email address</label>
                                <span style="position:relative; top:35px; left:10px;">
                                    <i class="fa fa-envelope-o"></i>
                                </span>
                            <input ng-model="emailModel" type="email" class="form-control em" id="emailadress" placeholder="E-mail" style="height:50px; padding: 6px 45px;">
                            <p class="help-block"><?='{{  email }}'?></p>

                        </div>
                        <div class="input form-group<?= "{{ hasPasswordError ? ' has-error' : '' }}" ?>">
                            <label for="password" class="sr-only">Password</label>
                                <span style="position:relative; top:40px; left:10px;">
                                    <img src="img/lg-key.png" style="height:25px;">
                                </span>
                            <input ng-model="passwordModel" type="password" class="form-control em" id="password" placeholder="Passwort" style="height:50px; padding: 6px 45px;">
                            <p class="help-block"><?='{{  password }}'?></p>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="chk-margin-float">
                                    <input type="checkbox" class="chk-float-left"><span class="remember-css">angemeldet bleiben</span>
                                </div>
                            </div><!-- /.col-lg-6 -->
                            <div class="col-lg-6">
                                <div class="btn-margin-float">
                                    <input ng-click="login()" type="submit" class="btn btn-primary" value="einloggen">
                                </div>
                            </div><!-- /.col-lg-6 -->
                        </div><!-- /.row -->
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="fgt-margin-float">
                                    <p class="forgt-pass"><a href="/password/email">Passwort vergessen?</a></p>
                                </div>
                            </div><!-- /.col-lg-6 -->
                        </div><!-- /.row -->
                        <hr>
                        <div class="row or-css">
                            <div class="col-lg-12">
                                <p>or</p>
                            </div><!-- /.col-lg-6 -->
                        </div><!-- /.row -->
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="">
                                    <a class="btn btn-block btn-social btn-facebook" style="box-shadow: 2px 3px 0px #0821A2">
                                        <i class="fa fa-facebook"></i>
                                        <span style="font-size: smaller;">Connect Facebook</span>
                                    </a>
                                </div>
                            </div><!-- /.col-lg-6 -->
                            <div class="col-lg-6">
                                <div class="">
                                    <a class="btn btn-block btn-social btn-google" style="box-shadow: 2px 3px 0px #770D00">
                                        <i class="fa fa-google"></i>
                                        <span style="font-size: smaller;">Connect Google</span>
                                    </a>
                                </div>
                            </div><!-- /.col-lg-6 -->
                        </div><!-- /.row -->
                    </form>
                </div>
                <div class="modal-footer login-footer">
                    <p class="footer-p"><a href="#">Neu registrieren</a></p>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->










</header>