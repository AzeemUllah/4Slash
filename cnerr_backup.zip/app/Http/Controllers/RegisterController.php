<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Redirect;
use Validator;
use Response;
use Auth;
use Hash;
use Mail;

use App\User;

class RegisterController extends Controller
{
    public function index()
    {

        return view('pages.register');

    }

    public function postRegister(Request $request)
    {

        $response = array();

        $userValidationData = [
            'username' => $request->input('username'),
            'email' => $request->input('email'),
            'password' => $request->input('password'),
            'password_confirmation' => $request->input('password_confirmation'),
        ];

        $userValidationRules = [
            'username' => 'required|unique:users|alpha_dash',
            'email' => 'required|email|unique:users|max:255',
            'password' => 'required|min:6|confirmed:password_confirmation',
        ];

        $validator = Validator::make($userValidationData, $userValidationRules);


        if ($request->ajax()) {

            if ($validator->fails()) {

                $response['error'] = true;

                if ($validator->errors()->has('email')) {
                    $response['errors']['emailError'] = true;
                    $response['errorsMessages']['emailError'] = $validator->errors()->first('email');
                } else {
                    $response['errors']['emailError'] = false;
                }
                if ($validator->errors()->has('username')) {
                    $response['errors']['usernameError'] = true;
                    $response['errorsMessages']['usernameError'] = $validator->errors()->first('username');
                } else {
                    $response['errors']['usernameError'] = false;
                }
                if ($validator->errors()->has('password')) {
                    $response['errors']['passwordError'] = true;
                    $response['errorsMessages']['passwordError'] = $validator->errors()->first('password');
                } else {
                    $response['errors']['passwordError'] = false;
                }

                return Response::json($response);
            }

            $activationCode = str_random(60) . $request->input('email');

            $user = new User();
            $user->username = $request->input('username');
            $user->email = $request->input('email');
            $user->password = Hash::make($request->input('password'));
            $user->type = 'user';
            $user->activation_code = $activationCode;
            if ($user->save()) {

                Mail::raw('Activate your email by going to this link: ' . url('/') . '/activate/email?token=' . $activationCode, function ($message) use ($request) {
                    $message->from('no-reply@cnerr.de', "Cnerr");
                    $message->to($request->input('email'), $name = null);
                    $message->subject('Activate Account');
                });

                $response['error'] = false;
//            $response['error'] = true;
//            $response['success'] = true;
//            $response['success_message'] = "Registration successfull please verify your email to continue.";
//
            }

            return Response::json($response);

        } else {

            if ($validator->fails()) {
                return Redirect::back()->withErrors($validator);
            }

            $activationCode = str_random(60) . $request->input('email');

            $user = new User();
            $user->username = $request->input('username');
            $user->email = $request->input('email');
            $user->password = Hash::make($request->input('password'));
            $user->type = 'user';
            $user->activation_code = $activationCode;
            if ($user->save()) {

                Mail::raw('Activate your email by going to this link: ' . url('/') . '/activate/email?token=' . $activationCode, function ($message) use ($request) {
                    $message->from('no-reply@cnerr.de', "Cnerr");
                    $message->to($request->input('email'), $name = null);
                    $message->subject('Activate Account');
                });

            }

            return Redirect::route('login')->with('successMessage', 'Registration successfull please verify your email to continue.');

        }

    }

}
