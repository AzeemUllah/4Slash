<?php

namespace App\Http\Controllers;

use App\Invoice;
use App\Order;
use App\Gig;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class PaymentsController extends Controller
{

    public function index(Request $request)
    {
        $user = Auth::user()->get();

        $completedOrdersAmount = Order::where(['user_id' => $user->id, 'status' => 'complete'])->sum('amount');
        $pendingOrdersAmount = Order::where(['user_id' => $user->id, 'status' => 'pending'])->orWhere(['user_id' => $user->id, 'status' => 'jobdone'])->sum('amount');

        $completedOrders = Order::where(['user_id' => $user->id, 'status' => 'complete'])->get();
        foreach($completedOrders as $completedOrder) {
            $completedOrder->gig = Gig::where(['id' => $completedOrder->gig_id])->first();
            $completedOrder->invoice = Invoice::where(['order_id' => $completedOrder->id])->first();
        }

        $data['completedOrdersAmount'] = $completedOrdersAmount;
        $data['pendingOrdersAmount'] = $pendingOrdersAmount;
        $data['completedOrders'] = $completedOrders;

        return view('pages.payments')->with($data);
    }


}
