<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;

use App\Order;
use App\Message;


class AgencyOrderController extends Controller
{
    public function index(Request $request)
    {
        $user = Auth::agency()->get();
        $order = Order::where(['order_no' => $request->input('orderno')])->first();

        $data['order'] = $order;
        $data['messages'] = Message::where(['order_id' => $order->id, 'to_id' => $user->id])->orWhere(['order_id' => $order->id, 'user_id' => $user->id])->get();

        return view('pages.agency.partials.single_order')->with($data);
    }

    function sendOrderMessage(Request $request) {

        $message = Message::sendMessage($request, Auth::agency()->get(), $request->input('orderuuid'), Auth::agency()->get()->username);

        return [ 'message' => $message->body, 'created_at' => date("d M h:i a", strtotime($message->created_at)) ];

    }
}