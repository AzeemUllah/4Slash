@include('includes.header')


        <!--content-->
<div class="container top-gap" ng-app="cnerr" ng-controller="MyOrdersController">
    <div class="well grey">
        <div class="row">
            <div class="col-lg-5">
                <h1 class="text-primary">Arbeitsverlauf</h1>
            </div>
        </div>
        {{--<div class="row wrk_stm">--}}
            {{--<div class="thumb">--}}
                {{--<div class="col-md-1 col-sm-1 box_1">--}}

                {{--</div>--}}
                {{--<div class="col-md-2 col-sm-2 box_1">--}}
                    {{--<p class="dollar">$0</p>--}}

                    {{--<p class="spent">Spend this Month</p>--}}
                    {{--<img src="{{ asset('img/dollar.png') }}">--}}
                {{--</div>--}}
                {{--<div class="col-md-2 col-sm-2 box_1">--}}
                    {{--<p class="dollar">0</p>--}}

                    {{--<p class="spent">New Orders</p>--}}
                    {{--<img src="{{ asset('img/pencil.png') }}">--}}
                {{--</div>--}}
                {{--<div class="col-md-2 col-sm-2 box_1">--}}
                    {{--<p class="dollar">0%</p>--}}

                    {{--<p class="spent">Positivity Gauge</p>--}}
                    {{--<img src="{{ asset('img/hand.png') }}">--}}
                {{--</div>--}}
                {{--<div class="col-md-2 col-sm-2 box_1">--}}
                    {{--<p class="dollar">0</p>--}}

                    {{--<p class="spent">Completed Orders</p>--}}
                    {{--<img src="{{ asset('img/jet.png') }}">--}}
                {{--</div>--}}
                {{--<div class="col-md-2 col-sm-2 box_1">--}}
                    {{--<p class="dollar">0 hrs.</p>--}}

                    {{--<p class="spent">Collaboration Time</p>--}}
                    {{--<img src="{{ asset('img/time.png') }}">--}}
                {{--</div>--}}
            {{--</div>--}}
        {{--</div>--}}
        <div class="row wrk-strm-chat">
            <div class="col-md-3 left-ubox">
                <div class="head">
                    <p>Meine Projekte</p>
                </div>
                <div class="list-group left-pane">





                    <div>

                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">in Bearbeitung </a></li>
                            <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Fertig</a></li>
                            <li role="presentation"><a href="#custom" aria-controls="custom" role="tab" data-toggle="tab">nach Maß</a></li>
                        </ul>

                        <!-- Tab panes -->
                        <div class="tab-content myorder-links-items">
                            <div role="tabpanel" class="tab-pane active" id="home">
                                @foreach($pendingOrders as $order)
                                    {{--<a href ng-click="getMyOrder('{{ $order->uuid }}')" class="list-group-item">--}}
                                        {{--@if($order->status == 'jobdone')--}}
                                            {{--<span class="myorders-list-item-status job-done-assets"><i class="icon fa fa-check"></i> job done</span>--}}
                                        {{--@endif--}}
                                        {{--{{ $order['gig']->title }}--}}
                                    {{--</a>--}}

                                    <a href="{{ route('getmyorder', [$order->order_no]) }}" class="list-group-item">
                                        @if($order->status == 'jobdone')
                                            <span class="myorders-list-item-status job-done-assets"><i class="icon fa fa-check"></i> job done</span>
                                        @endif
                                        {{ (($order->type == 'gig') ? $order['gig']->title : (($order->type == 'package') ? $order['package']->title : '')) }}
                                    </a>
                                @endforeach
                            </div>
                            <div role="tabpanel" class="tab-pane" id="profile">
                                @foreach($completedOrders as $order)
                                    {{--<a href ng-click="getMyOrder('{{ $order->uuid }}')" class="list-group-item">--}}
                                        {{--{{ $order['gig']->title }}--}}
                                    {{--</a>--}}

                                    <a href="{{ route('getmyorder', [$order->order_no]) }}" class="list-group-item">
                                        {{ (($order->type == 'gig') ? $order['gig']->title : (($order->type == 'package') ? $order['package']->title : '')) }}
                                    </a>
                                @endforeach
                            </div>
                            <div role="tabpanel" class="tab-pane" id="custom">
                                @foreach($customOrders as $order)
                                    {{--<a href ng-click="getMyOrder('{{ $order->uuid }}')" class="list-group-item">--}}
                                        {{--{{ $order['gig']->title }}--}}
                                    {{--</a>--}}

                                    <a href="{{ route('getmyorder', [$order->order_no]) }}" class="list-group-item">
                                        {{ $order->company_email }}
                                    </a>
                                @endforeach
                            </div>
                        </div>

                    </div>













                </div>
            </div>
            <div class="col-md-9 right-ubox">
                <div class="pane-head col-md-12">
                    <span>My Chat</span>
                    <span class="pull-right">Order No: <span class="innertext-order-no"></span></span>
                </div>
                <div class="col-md-12 rating-box-container"><input class="rating" type="text" data-min="0" data-max="5" data-step="1"></div>
                <div class="chat-window col-md-12">
                     <div class="alert alert-success alert-dismissible job-done-assets">
                        <h4><i class="icon fa fa-check"></i> This order mark as Job Done.</h4>
                        please wait for the buyer to acknowledge this order.
                         <div>
                            <form class="message-alert-box" method="post" action="{{ route('order.acknowledge') }}">
                                <input type="hidden" name="order-no" class="input-order-no">
                                <button type="submit" class="btn btn-primary">Acknowledge</button>
                            </form>
                             <form class="message-alert-box" id="formAskForModification" method="post" action="{{ route('order.askformodification') }}">
                                 <input type="hidden" name="order-no" class="input-order-no">
                                 <button type="submit" name="askForModification" class="btn btn-primary">Ask for modification</button>
                             </form>
                         </div>
                    </div>
                    <div class="upr-wind text-center">
                        <div class="days">
                            <div class="dy">
                                00
                            </div>
                            DAYS
                        </div>
                        <div class="hours">
                            <div class="hr">
                                00
                            </div>
                            HOURS
                        </div>
                        <div class="minutes">
                            <div class="mint">
                                00
                            </div>
                            MINUTES
                        </div>
                        <div class="seconds">
                            <div class="sec">
                                00
                            </div>
                            SECONDS
                        </div>
                    </div>
                    
                    <div class="chat-box">
                        <div class="info-part">
                            <h4>Show Order Info</h4>
                        </div>
                        <div class="chat">

                            <h4>Order Info</h4>
                            <table>
                                <tr>
                                    <td class="left">Order Amount:</td>
                                    <td class="right" id="orderAmout"></td>
                                </tr>
                                <tr>
                                    <td class="left">Order Date:</td>
                                    <td class="right" id="orderDate"></td>
                                </tr>
                            </table>


                            <h4><span>Company Info</h4>
                            <table class="table">
                                <tr style="display:none;">
                                    <td class="left">Company Name:</td>
                                    <td class="right" id="companyName"></td>
                                </tr>
                                <tr style="display:none;">
                                    <td class="left">Tagline:</td>
                                    <td class="right" id="companyTagline"></td>
                                </tr>
                                <tr style="display:none;">
                                    <td class="left">Industry:</td>
                                    <td class="right" id="companyIndustry"></td>
                                </tr>
                                <tr>
                                    <td class="left">Description:</td>
                                    <td class="right" id="companyDescription"></td>
                                </tr>
                            </table>
                            <hr>


                            <div ng-repeat="question in order.ques_ans">
                                <h4><?= '{{ question.question }}' ?></h4>

                                <p style="font-size:16px;color:#7b7b7b;"><?= '{{ question.answers }}' ?></p>
                                <hr>
                            </div>



                            {{--<h4>Sample Styles</h4>--}}

                            {{--<div class="scrl1">--}}
                                {{--<span class="play">Playful</span>--}}
                                {{--<input id="ex1" data-slider-id='ex1Slider' type="text" data-slider-min="0"--}}
                                       {{--data-slider-max="20" data-slider-step="1" data-slider-value="14"/>--}}
                                {{--<span class="serious">Serious</span>--}}
                            {{--</div>--}}
                            {{--<div class="scrl2">--}}
                                {{--<span class="modern">Modern</span>--}}
                                {{--<input id="ex2" data-slider-id='ex1Slider' type="text" data-slider-min="0"--}}
                                       {{--data-slider-max="20" data-slider-step="1" data-slider-value="14"/>--}}
                                {{--<span class="classic">Classic</span>--}}
                            {{--</div>--}}
                            {{--<div class="scrl3">--}}
                                {{--<span class="femin">Feminine</span>--}}
                                {{--<input id="ex3" data-slider-id='ex1Slider' type="text" data-slider-min="0"--}}
                                       {{--data-slider-max="20" data-slider-step="1" data-slider-value="14"/>--}}
                                {{--<span class="masculin">Masculine</span>--}}
                            {{--</div>--}}
                            {{--<div class="scrl4">--}}
                                {{--<span class="simple">Simple</span>--}}
                                {{--<input id="ex4" data-slider-id='ex1Slider' type="text" data-slider-min="0"--}}
                                       {{--data-slider-max="20" data-slider-step="1" data-slider-value="14"/>--}}
                                {{--<span class="complex">Complex</span>--}}
                            {{--</div>--}}
                        </div>
                    </div>


                    <div class="zg-chat-box-list">
                    </div>



                </div>
                <div class="chat-text-box-block col-md-12">
                    <form method="post" id="order-messaging-form" action="{{ route('order.post.message') }}">
                        <div class="row">
                            <div class="col-md-12">
                                <input type="file" name="file-attachment" id="order-message-file-selector">
                                <label id="order-message-file-selector-button" for="order-message-file-selector"><span class="glyphicon glyphicon-paperclip"></span></label>
                                &nbsp;&nbsp;<span class="selected-file"></span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-10 frm" style="padding:0px;">
                                <input type="hidden" name="order-no" id="orderNo">
                                <input type="text" name="message" class="form-control pull-left txtMessage"
                                          placeholder="Click here to type">
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-primary pull right"
                                        style="padding:5px 30px;">Send
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@include('includes.footer')


<script src="{{ asset('bower_components/jquery.countdown/dist/jquery.countdown.js') }}"></script>


<script type="text/javascript">
    $('#ex1').bootstrapSlider({
        tooltip: 'hide'
    });

    $('#ex2').bootstrapSlider({
        tooltip: 'hide'
    });
    $('#ex3').bootstrapSlider({
        tooltip: 'hide'
    });
    $('#ex4').bootstrapSlider({
        tooltip: 'hide'
    });
</script>

<script type="text/javascript">
    $(document).ready(function () {
        $(".info-part").click(function () {
            $(".chat").slideToggle();
        });
    });
</script>
<script>
    (function() {
        document.querySelector('#order-messaging-form').addEventListener('submit', function(event) {
                event.preventDefault();

                var form = this;
                var btnSubmit = $(this).find('button[type=submit]');
                var txtMessage = document.querySelector('.txtMessage');
                btnSubmit.attr('disabled', 'disabled');
                var formData = new FormData(form);

            
                $.ajax({
                    url: form.action,
                    method: 'post',
                    data: formData,
                    enctype: 'multipart/form-data',
                    processData: false,
                    contentType: false,
                    success: function(data) {
                        var elem = $('<div class="chat-box3">' +
                                        '<img src="'+ $('.head-profile-image img').attr('src') +'" class="img-circle">' +
                                        '<div class="ng-binding chat3">'+ data.message +'</div>' +
                                    '</div>');
                        
                        $('.zg-chat-box-list').append(elem);
                        txtMessage.value = "";

                        btnSubmit.removeAttr('disabled');
                    },
                    error: function() {
                        btnSubmit.removeAttr('disabled');
                        btnSubmit.value = "";
                    }
                });
            });

        document.getElementById('formAskForModification').addEventListener('submit', function(e) {
            e.preventDefault();

            var form = this;
            var formData = new FormData(form);

            $.ajax({
                url: form.action,
                method: 'post',
                data: formData,
                processData: false,
                contentType: false,
                success: function(data) {
                    if(data.status)
                    {
                        $(form).parent().parent().remove();
                        notifyMessage(data.msg, 'success');
                    }
                },
                error: function() {
                    console.log('something went wrong please try again later.');
                }
            });
        });

        document.getElementById('order-message-file-selector').addEventListener('change', function(e) {
            if(e.target.files.length > 0) {
                document.querySelector('.selected-file').innerText = e.target.files[0].name;
            } else {
                document.querySelector('.selected-file').innerText = "";
            }
        })

        document.querySelector('.myorder-links-items').addEventListener('click', function(e) {
            e.preventDefault();
            var link = e.srcElement;

            $.ajax({
                url: link.href,
                method: 'get',
                success: function(data) {
                    console.log(data);
                    $('.right-ubox').show();

                    if(data.status == 'jobdone')
                        $('.job-done-assets').show();
                    else
                        $('.job-done-assets').hide();

                    document.querySelector('#orderNo').value = data.order_no;

                    var orderNoInputList = document.querySelectorAll('.input-order-no');
                    [].forEach.call(orderNoInputList, function(orderNoInput) {
                        orderNoInput.value = data.order_no;
                    });

                    var orderNoInnerTextList = document.querySelectorAll('.innertext-order-no');
                    [].forEach.call(orderNoInnerTextList, function(orderNoInnerText) {
                        orderNoInnerText.innerText = data.order_no;
                    });

                    document.querySelector('#companyName').innerText = data.company_name;
                    document.querySelector('#companyTagline').innerText = data.company_tagline;
                    document.querySelector('#companyIndustry').innerText = data.company_industry;
                    document.querySelector('#companyDescription').innerText = data.company_discription;
                    document.querySelector('#orderAmout').innerHTML = "&euro;" + data.amount;
                    document.querySelector('#orderDate').innerText = data.created_at;

                    var messages = '';
                    var totalMessages = data.messages.length;
                    data.messages.forEach(function(element, index, array) {
                        var message = ((data.messages[(parseInt(totalMessages) - (parseInt(index) + 1))].from == 'me') ? '<div class="chat-box3">' : '<div class="chat-box2">')
                                + ((data.messages[(parseInt(totalMessages) - (parseInt(index) + 1))].profile_image != null) ? '<img src="" class="img-circle">' : '<div style="border-radius:50%;width:50px;height:50px;background-color:gray;display:inline-block;position:relative;"><span style="position:absolute;left:50%;top:50%;transform:translate(-50%, -50%);font-size:30px;color:white;">'+ data.messages[(parseInt(totalMessages) - (parseInt(index) + 1))].from_user_name_first_char +'</span></div>')
                                + ((data.messages[(parseInt(totalMessages) - (parseInt(index) + 1))].from == 'me') ? '<div class="chat3">' : '<div class="chat2">')
                                + '<p>'+ data.messages[(parseInt(totalMessages) - (parseInt(index) + 1))].body +'</p>'
                                + '</div>'
                                + '</div>';

                        messages += message;
                    });
                    document.querySelector('.zg-chat-box-list').innerHTML = messages;


                    
                        if (data.status != 'complete' && data.type != 'package' && data.type != "custom") {
                            $('.upr-wind').show();

                            $('.upr-wind').countdown(data.expiry, {elapse: true}).on('update.countdown', function (event) {
                                var $this = $(this);
                                if (event.elapsed) {
                                    $this.html(event.strftime('<div class="days expire-date"><div class="dy">%D</div>Days</div><div class="hours expire-date"><div class="hr">%H</div>HOURS</div><div class="minutes expire-date"><div class="mint">%M</div>Minutes</div><div class="seconds expire-date"><div class="sec">%S</div>Seconds</div>'));
                                } else {
                                    $this.html(event.strftime('<div class="days"><div class="dy">%D</div>Days</div><div class="hours"><div class="hr">%H</div>HOURS</div><div class="minutes"><div class="mint">%M</div>Minutes</div><div class="seconds"><div class="sec">%S</div>Seconds</div>'));
                                }
                            });
                        } else {
                            $('.upr-wind').hide();
                        }




                }
            });
        });


    })();
</script>
<script>
    //  $(function(){
    //    $('.zg-chat-box-list').slimScroll({
    //      height: '500px',
    //      size: '5px',
    //      start: 'bottom',
    //      railVisible: true,
    //      railColor: '#222',
    //      railOpacity: 0.3,
    //      wheelStep: 10,
    //      disableFadeOut: false
    //    });
    //  });
</script>

</body>
</html>