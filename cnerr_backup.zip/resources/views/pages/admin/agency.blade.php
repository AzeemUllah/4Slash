@extends('pages.admin.admin_template')


@section('header_title')


@endsection




@section('content')
    <div class="row">
        <div class="col-md-12">
            <!-- Widget: user widget style 1 -->
            <div class="box box-widget widget-user">
                <!-- Add the bg color to the header using any of the bg-* classes -->
                <div class="widget-user-header bg-aqua-active">
                    <h3 class="widget-user-username">{{ $agency->name }}</h3>
                    <h5 class="widget-user-desc"></h5>
                </div>
                <div class="widget-user-image">
                    <img class="img-circle" src="http://placehold.it/128x128" alt="User Avatar">
                </div>
                <div class="box-footer">
                    <div class="row">
                        <div class="col-sm-4 border-right">
                            <div class="description-block">
                                <h5 class="description-header"></h5>
                                <span class="description-text"></span>
                            </div>
                            <!-- /.description-block -->
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-4 border-right">
                            <div class="description-block">
                                <h5 class="description-header">Wallet Amount</h5>
                                <span class="description-text">{{ $agency->wallet }}</span>
                            </div>
                            <!-- /.description-block -->
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-4">
                            <div class="description-block">
                                <h5 class="description-header"></h5>
                                <span class="description-text">
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
                                        Withdraw Amount
                                    </button>

                                                                        <!-- Modal -->
                                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                                                aria-hidden="true">&times;</span></button>
                                                    <h4 class="modal-title" id="myModalLabel">Confirm</h4>
                                                </div>
                                                <div class="modal-body">
                                                    Do you really want to withdraw Amount?
                                                </div>
                                                <div class="modal-footer">
                                                    <form method="post" action="{{ route('agency.amount.withdraw') }}">
                                                        <input type="hidden" name="agencyId" value="{{ $agency->id }}">
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                                        <button type="submit" class="btn btn-primary">Confirm</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </span>
                            </div>
                            <!-- /.description-block -->
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
            </div>
            <!-- /.widget-user -->

            <div>
                <h2>Orders</h2>

                <!-- Nav tabs -->
                <ul class="nav nav-tabs" role="tablist">
                    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab"
                                                              data-toggle="tab">Pending Orders
                            ({{ $agency['pendingOrders']->count() }})</a></li>
                    <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Completed
                            Orders ({{ $agency['completedOrders']->count() }})</a>
                    </li>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane active" id="home">
                        <div class="box box-info">
                            <div class="box-header with-border">
                                <h3 class="box-title">Pending Orders ({{ $agency['pendingOrders']->count() }})</h3>

                                <div class="box-tools pull-right">
                                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i
                                                class="fa fa-minus"></i>
                                    </button>
                                    {{--<button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>--}}
                                </div>
                            </div>
                            <!-- /.box-header -->
                            <div class="box-body">
                                <div class="table-responsive">
                                    <table class="table no-margin">
                                        <thead>
                                        <tr>
                                            <th>Order No</th>
                                            <th>Gig</th>
                                            <th>Company Name</th>
                                            <th>Expire Date</th>
                                            <th>Amount</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($agency['pendingOrders'] as $pendingOrder)
                                            <tr>
                                                <td>{{ $pendingOrder->order_no }}</td>
                                                <td>{{ $pendingOrder->gig->title }}</td>
                                                <td>{{ $pendingOrder->company_name }}</td>
                                                <td>{{ $pendingOrder->expiry }}</td>
                                                <td>{{ $pendingOrder->amount }}</td>
                                                <td>
                                                    <a href="{{ route('adminorder', [$pendingOrder->order_no, $pendingOrder->uuid]) }}"
                                                       class="btn btn-primary btn-xs"><span
                                                                class="glyphicon glyphicon-eye-open"></span></a>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                                <!-- /.table-responsive -->
                            </div>
                            <!-- /.box-body -->
                            <div class="box-footer clearfix">
                                {{--<a href="javascript::;" class="btn btn-sm btn-info btn-flat pull-left">Place New Order</a>--}}
                                {{--<a href="javascript::;" class="btn btn-sm btn-default btn-flat pull-right">View All Orders</a>--}}
                            </div>
                            <!-- /.box-footer -->
                        </div>
                    </div>
                    <div role="tabpanel" class="tab-pane" id="profile">
                        <div class="box box-info">
                            <div class="box-header with-border">
                                <h3 class="box-title">Completed Orders ({{ $agency['completedOrders']->count() }})</h3>

                                <div class="box-tools pull-right">
                                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i
                                                class="fa fa-minus"></i>
                                    </button>
                                    {{--<button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>--}}
                                </div>
                            </div>
                            <!-- /.box-header -->
                            <div class="box-body">
                                <div class="table-responsive">
                                    <table class="table no-margin">
                                        <thead>
                                        <tr>
                                            <th>Order No</th>
                                            <th>Gig</th>
                                            <th>Company Name</th>
                                            <th>Expire Date</th>
                                            <th>Amount</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($agency['completedOrders'] as $completedOrder)
                                            <tr>
                                                <td>{{ $completedOrder->order_no }}</td>
                                                <td>{{ $completedOrder->gig->title }}</td>
                                                <td>{{ $completedOrder->company_name }}</td>
                                                <td>{{ $completedOrder->expiry }}</td>
                                                <td>{{ $completedOrder->amount }}</td>
                                                <td>
                                                    <a href="{{ route('adminorder', [$completedOrder->order_no, $completedOrder->uuid]) }}"
                                                       class="btn btn-primary btn-xs"><span
                                                                class="glyphicon glyphicon-eye-open"></span></a>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                                <!-- /.table-responsive -->
                            </div>
                            <!-- /.box-body -->
                            <div class="box-footer clearfix">
                                {{--<a href="javascript::;" class="btn btn-sm btn-info btn-flat pull-left">Place New Order</a>--}}
                                {{--<a href="javascript::;" class="btn btn-sm btn-default btn-flat pull-right">View All Orders</a>--}}
                            </div>
                            <!-- /.box-footer -->
                        </div>

                    </div>
                </div>

            </div>


            <div>
                <h2>Payment History</h2>

                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Payment History</h3>

                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i
                                        class="fa fa-minus"></i>
                            </button>
                            {{--<button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>--}}
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class="table-responsive">
                            <table class="table no-margin">
                                <thead>
                                <tr>
                                    <th>Detail</th>
                                    <th>Payable</th>
                                    <th>Paid</th>
                                    <th>Balance</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($agency['agencyInvoices'] as $agencyInvoice)
                                    <tr>
                                        <td>{{ $agencyInvoice->detail }}</td>
                                        <td>{{ $agencyInvoice->payable }}</td>
                                        <td>{{ $agencyInvoice->paid }}</td>
                                        <td>{{ $agencyInvoice->balance }}</td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer clearfix">
                        {{--<a href="javascript::;" class="btn btn-sm btn-info btn-flat pull-left">Place New Order</a>--}}
                        {{--<a href="javascript::;" class="btn btn-sm btn-default btn-flat pull-right">View All Orders</a>--}}
                    </div>
                    <!-- /.box-footer -->
                </div>

            </div>


        </div>
    </div>

    @endsection


    @section('pages_css')

            <!-- DataTables -->
    <link rel="stylesheet" href="{{ asset('bower_components/AdminLTE/plugins/datatables/dataTables.bootstrap.css') }}">

    @endsection


    @section('pages_script')

            <!-- DataTables -->
    <script src="{{ asset('bower_components/AdminLTE/plugins/datatables/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('bower_components/AdminLTE/plugins/datatables/dataTables.bootstrap.min.js') }}"></script>
    <!-- page script -->
    <script>
        $(function () {
            var table = $("#example1").DataTable();

            $('#example1 tbody').on('click', 'button.btn-del', function () {

                table.row($(this).parents('tr')).remove().draw();

            });

        });
    </script>

@endsection