@extends('pages.agency.agency_template')

@section('header_title')

    <h1>Dashboard</h1>

@endsection

@section('content')


    {{--<div class="row">--}}
        {{--<div class="col-md-3 col-sm-6 col-xs-12">--}}
            {{--<div class="info-box">--}}
                {{--<span class="info-box-icon bg-aqua"><i class="ion ion-ios-gear-outline"></i></span>--}}

                {{--<div class="info-box-content">--}}
                    {{--<span class="info-box-text">CPU Traffic</span>--}}
                    {{--<span class="info-box-number">90<small>%</small></span>--}}
                {{--</div>--}}
                {{--<!-- /.info-box-content -->--}}
            {{--</div>--}}
            {{--<!-- /.info-box -->--}}
        {{--</div>--}}
        {{--<!-- /.col -->--}}
        {{--<div class="col-md-3 col-sm-6 col-xs-12">--}}
            {{--<div class="info-box">--}}
                {{--<span class="info-box-icon bg-red"><i class="fa fa-google-plus"></i></span>--}}

                {{--<div class="info-box-content">--}}
                    {{--<span class="info-box-text">Likes</span>--}}
                    {{--<span class="info-box-number">41,410</span>--}}
                {{--</div>--}}
                {{--<!-- /.info-box-content -->--}}
            {{--</div>--}}
            {{--<!-- /.info-box -->--}}
        {{--</div>--}}
        {{--<!-- /.col -->--}}

        {{--<!-- fix for small devices only -->--}}
        {{--<div class="clearfix visible-sm-block"></div>--}}

        {{--<div class="col-md-3 col-sm-6 col-xs-12">--}}
            {{--<div class="info-box">--}}
                {{--<span class="info-box-icon bg-green"><i class="ion ion-ios-cart-outline"></i></span>--}}

                {{--<div class="info-box-content">--}}
                    {{--<span class="info-box-text">Sales</span>--}}
                    {{--<span class="info-box-number">760</span>--}}
                {{--</div>--}}
                {{--<!-- /.info-box-content -->--}}
            {{--</div>--}}
            {{--<!-- /.info-box -->--}}
        {{--</div>--}}
        {{--<!-- /.col -->--}}
        {{--<div class="col-md-3 col-sm-6 col-xs-12">--}}
            {{--<div class="info-box">--}}
                {{--<span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>--}}

                {{--<div class="info-box-content">--}}
                    {{--<span class="info-box-text">New Members</span>--}}
                    {{--<span class="info-box-number">2,000</span>--}}
                {{--</div>--}}
                {{--<!-- /.info-box-content -->--}}
            {{--</div>--}}
            {{--<!-- /.info-box -->--}}
        {{--</div>--}}
        {{--<!-- /.col -->--}}
    {{--</div>--}}

    <div class="row">
        <div class="col-md-3">
            <div class="box box-solid">
                <div class="box-header with-border">
                    <h3 class="box-title">Orders</h3>
                    <div class="box-tools">
                        <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body no-padding">
                    <ul class="nav nav-pills nav-stacked agency-side-menu">
                        <li class="active"><a href id="btnPending" data-url="{{ route('agencyorderslist') }}?status=pending"><i class="fa fa-inbox"></i> Pending </a></li>
                        {{--<span class="label label-primary pull-right">12</span>--}}
                        {{--<span class="label label-warning pull-right">65</span>--}}
                        <li><a href id="btnCompleted" data-url="{{ route('agencyorderslist') }}?status=complete"><i class="fa fa-filter"></i> Completed </a></li>
                    </ul>
                </div><!-- /.box-body -->
            </div><!-- /. box -->

        </div><!-- /.col -->
        <div class="col-md-9">
            <div class="box box-primary" id="boxMain">








                <div class="box-header with-border">
                    <h3 class="box-title">Orders</h3>
                    <div class="box-tools pull-right">
                        <div class="has-feedback">
                            <input type="text" class="form-control input-sm" placeholder="Search Mail">
                            <span class="glyphicon glyphicon-search form-control-feedback"></span>
                        </div>
                    </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body no-padding">
                    {{--<div class="mailbox-controls">--}}
                        {{--<!-- Check all button -->--}}
                        {{--<button class="btn btn-default btn-sm checkbox-toggle"><i class="fa fa-square-o"></i></button>--}}
                        {{--<div class="btn-group">--}}
                            {{--<button class="btn btn-default btn-sm"><i class="fa fa-trash-o"></i></button>--}}
                            {{--<button class="btn btn-default btn-sm"><i class="fa fa-reply"></i></button>--}}
                            {{--<button class="btn btn-default btn-sm"><i class="fa fa-share"></i></button>--}}
                        {{--</div><!-- /.btn-group -->--}}
                        {{--<button class="btn btn-default btn-sm"><i class="fa fa-refresh"></i></button>--}}
                        {{--<div class="pull-right">--}}
                            {{--1-50/200--}}
                            {{--<div class="btn-group">--}}
                                {{--<button class="btn btn-default btn-sm"><i class="fa fa-chevron-left"></i></button>--}}
                                {{--<button class="btn btn-default btn-sm"><i class="fa fa-chevron-right"></i></button>--}}
                            {{--</div><!-- /.btn-group -->--}}
                        {{--</div><!-- /.pull-right -->--}}
                    {{--</div>--}}
                    <div class="table-responsive mailbox-messages">
                        <table class="table table-hover table-striped table-orders">
                            <tbody>
                            @foreach($orders as $order)
                                <tr>
                                    {{--<td><input type="checkbox"></td>--}}
                                    {{--<td class="mailbox-star"><a href="#"><i class="fa fa-star text-yellow"></i></a></td>--}}
                                    <td class="mailbox-name"><a class="order-link" href="#" data-href="{{ route('agencyorder') }}?orderno={{ $order->order_no }}">{{ $order->order_no }}</a></td>
                                    <td class="mailbox-subject"><b>AdminLTE 2.0 Issue</b> - Trying to find a solution to this problem...</td>
                                    <td class="mailbox-attachment"></td>
                                    <td class="mailbox-date">5 mins ago</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table><!-- /.table -->
                    </div><!-- /.mail-box-messages -->
                </div><!-- /.box-body -->
                <div class="box-footer no-padding">
                    <div class="mailbox-controls">
                        <!-- Check all button -->
                        {{--<button class="btn btn-default btn-sm checkbox-toggle"><i class="fa fa-square-o"></i></button>--}}
                        {{--<div class="btn-group">--}}
                            {{--<button class="btn btn-default btn-sm"><i class="fa fa-trash-o"></i></button>--}}
                            {{--<button class="btn btn-default btn-sm"><i class="fa fa-reply"></i></button>--}}
                            {{--<button class="btn btn-default btn-sm"><i class="fa fa-share"></i></button>--}}
                        {{--</div><!-- /.btn-group -->--}}
                        {{--<button class="btn btn-default btn-sm"><i class="fa fa-refresh"></i></button>--}}
                        <div class="pull-right">
                            1-50/200
                            <div class="btn-group">
                                <button class="btn btn-default btn-sm"><i class="fa fa-chevron-left"></i></button>
                                <button class="btn btn-default btn-sm"><i class="fa fa-chevron-right"></i></button>
                            </div><!-- /.btn-group -->
                        </div><!-- /.pull-right -->
                    </div>
                </div>







            </div><!-- /. box -->
        </div><!-- /.col -->
    </div><!-- /.row -->



@endsection




@section('pages_script')
    <script>
        (function() {
            document.querySelector('.agency-side-menu').addEventListener('click', function(e) {
                e.preventDefault();
                var clickedElement = e.srcElement;

                $('#boxMain').append('<div class="overlay agency-loader"><i class="fa fa-refresh fa-spin"></i></div>');
                $.ajax({
                    url: $(clickedElement).data('url'),
                    method: 'get',
                    success: function(data) {
                        console.log(data);
                        $('#boxMain').html(data);
                        $('.agency-loader').remove();
                    }
                });
            });

            document.querySelector('#boxMain').addEventListener('click', function(e) {
                if(e.srcElement.tagName == 'A') {
                    e.preventDefault();


                    var clickedElement = e.srcElement;


                    $('#boxMain').append('<div class="overlay agency-loader"><i class="fa fa-refresh fa-spin"></i></div>');
                    $.ajax({
                        url: $(clickedElement).attr('data-href'),
                        method: 'get',
                        success: function (data) {
                            $('#boxMain').html(data);
                            $('.agency-loader').remove();
                        }
                    });
                }
            })
        })();
    </script>
@endsection