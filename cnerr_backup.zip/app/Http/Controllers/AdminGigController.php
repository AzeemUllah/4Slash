<?php

namespace App\Http\Controllers;


use App\Gig;
use App\GigImages;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Redirect;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class AdminGigController extends Controller
{

    public function removeGigImage(Request $request) {

        GigImages::removeGigImage($request->input('gig-image-id'));

    }

    public function update(Request $request) {

        $gigData['gig']['id'] = $request->input('gig-id');
        $gigData['gig']['gig-category-id'] = $request->input('gig-category');
        $gigData['gig']['gig-sub-category-id'] = $request->input('gig-sub-category');
        $gigData['gig']['gig-slug'] = str_replace(' ', '_', strtolower($request->input('gig-title')));
        $gigData['gig']['gig-title'] = $request->input('gig-title');
        $gigData['gig']['gig-short-discription'] = $request->input('gig-short-discription');
        $gigData['gig']['gig-discription'] = $request->input('gig-discription');
        $gigData['gig']['gig-delivery-days'] = $request->input('gig-delivery-days');
        $gigData['gig']['gig-price'] = $request->input('gig-price');


        if(Gig::gigUpdate($gigData, $request)) {
            return redirect()->route('admingigs');
        }
    }

    public function gigActivate(Request $request) {
        $gigId = $request->input('gig-id');

        return ['status' => Gig::gigActivate($gigId)];
    }

    public function gigFeatured(Request $request) {
        $gigId = $request->input('gig-id');

        return ['status' => Gig::gigFeatured($gigId)];
    }

}
