<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class AdminLoginController extends Controller
{

    public function index()
    {
        if(Auth::admin()->check())
        {
            return redirect()->route('admindashboard');


        }

        return view('pages.admin.login');

    }


}
