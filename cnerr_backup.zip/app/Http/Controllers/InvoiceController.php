<?php

namespace App\Http\Controllers;


use App\Gig;
use App\Invoice;
use App\Order;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use PDF;


class InvoiceController extends Controller
{
    public function index($orderNo, $invoiceNo)
    {

        $invoice = Invoice::where(['invoice_no' => $invoiceNo])->first();
        $order = Order::where(['id' => $invoice->order_id])->first();
        $gig = Gig::where(['id' => $order->gig_id])->first();

        $order->invoice = $invoice;
        $order->gig = $gig;

        $data['order'] = $order;

        return PDF::loadView('pages.invoice', $data)->stream();
        //return view('pages.invoice');

    }
}

