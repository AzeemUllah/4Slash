<!-- Main Footer -->
<footer class="main-footer">

    <!-- Default to the left -->
    <strong>Copyright &copy; 2015 <a href="#">Cnerr</a>.</strong> All rights reserved.
</footer>