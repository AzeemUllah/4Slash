<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use RecursiveIterator;

class Gigtype extends Model
{
    protected $fillable = ['slug', 'name'];

    public static function createNewGigType($gigTypeName = "", array $gigTypeSubcategoriesName = null) {
        $gigCategory = new Gigtype();
        $gigCategory->slug = str_replace(' ', '_', strtolower($gigTypeName));
        $gigCategory->name = $gigTypeName;
        $gigCategory->save();

        if($gigTypeSubcategoriesName != null) {
            if(is_array($gigTypeSubcategoriesName)) {
                foreach($gigTypeSubcategoriesName as $gigTypeSubcategoryName) {
                    $gigTypeSubcategory = new Gigtype_Subcategory();
                    $gigTypeSubcategory->slug = str_replace(' ', '_', strtolower($gigTypeSubcategoryName));
                    $gigTypeSubcategory->name = $gigTypeSubcategoryName;
                    $gigTypeSubcategory->gigtypes_id = $gigCategory->id;
                    $gigTypeSubcategory->save();
                }
            }
        }
    }

    public static function categoryUpdate($request) {

        $catId = $request->input('category-id');
        $catName = $request->input('category-name');
        $subCats = $request->input('subcategories');

        $result = DB::transaction(function () use ($catId, $catName, $subCats) {

            try {

                $cat = self::where(['id' => $catId])->first();
                $cat->name = $catName;
                $cat->slug = str_replace(' ', '_', strtolower($catName));
                $cat->save();

                Gigtype_Subcategory::where(['gigtypes_id' => $cat->id])->delete();

                if ($subCats) {
                    foreach ($subCats as $subCat) {
                        $subCategory = new Gigtype_Subcategory();
                        $subCategory->slug = str_replace(' ', '_', strtolower($subCat));
                        $subCategory->name = $subCat;
                        $subCategory->gigtypes_id = $cat->id;
                        $subCategory->save();
                    }
                }

                 return true;

            } catch(\Exception $e) {

                return false;

            }

        });

        return $result;

    }
}
