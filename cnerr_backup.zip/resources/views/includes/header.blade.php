<!DOCTYPE html>
<html>
<head>
    <title>Cnerr</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="/img/cnerrfav.png" type="image/png">
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script type="text/javascript" src="{{ asset('js/myjslib.js') }}"></script>
    <link rel="stylesheet" type="text/css" href="{{ asset('css/cnerr-app.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('node_modules/bootstrap/dist/css/bootstrap.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/star-rating.min.css') }}">
    <link rel="stylesheet" type="text/css" href='https://fonts.googleapis.com/css?family=Raleway:400,500,600,700,800,900,200,300,100' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap-social.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/font-awesome.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/awesome-bootstrap-checkbox.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/flexslider.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/slick.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/slick-theme.css') }}">
    <link rel="stylesheet" type="text/css" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap-slider.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap-select.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/A-style.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/A-style - Copy.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/O-style.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/Z-style.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/c-style.css') }}">
   
</head>
<body ng-app="cnerr">

@include('pages.partials.fiverr-components.header-nav')


</div>