@extends('pages.admin.admin_template')


@section('header_title')

    <h1>Gigs</h1>

@endsection




@section('content')
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header text-right">
                    <a href="{{ route('gigcreate') }}" class="btn btn-primary btn-sm"><span class="fa fa-plus"></span></a>
                </div><!-- /.box-header -->
                <div class="box-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>Title</th>
                            <th>Short Discription</th>
                            <th>Category</th>
                            <th>Delivery Days</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody class="form-gigs-body-container">
                        @foreach($gigs as $gig)
                            <tr>
                                <td>{{ $gig->title }}</td>
                                <td>{{ $gig->short_discription }}</td>
                                <td>{{ \App\Gigtype::find($gig->gigtype_id)->name }}</td>
                                <td>{{ $gig->delivery_days }}</td>
                                <td>
                                    {{--<button class="btn btn-primary btn-xs"><span class="fa fa-edit"></span></button>--}}
                                    <form id="formGigActivate" method="post" action="{{ route('gig.activate') }}">
                                        <input type="hidden" name="gig-id" value="{{ $gig->id }}">
                                        @if(!$gig->active)
                                            <button type="button" class="btn btn-primary btn-xs btn-gig-activate">Activate</button>
                                        @else
                                            <button type="button" class="btn btn-success btn-xs btn-gig-activate">Activate</button>
                                        @endif
                                    </form>
                                    <form id="formGigFeatured" method="post" action="{{ route('gig.featured') }}">
                                        <input type="hidden" name="gig-id" value="{{ $gig->id }}">
                                        @if(!$gig->featured)
                                            <button type="button" class="btn btn-primary btn-xs btn-gig-activate">Featured</button>
                                        @else
                                            <button type="button" class="btn btn-success btn-xs btn-gig-activate">Featured</button>
                                        @endif
                                    </form>
                                    <form style="display: inline-block;" method="get" action="{{ route('gigcreate') }}">
                                        <input type="hidden" name="action" value="update">
                                        <input type="hidden" name="funnel" value="{{ $gig->uuid }}">
                                        <button type="submit" class="btn btn-default btn-xs"><span class="fa fa-pencil"></span></button>
                                    </form>
                                    <button data-id="{{ $gig->id }}" data-url="{{ route('adminGigDelete') }}" class="btn btn-danger btn-xs btn-del"><span class="fa fa-trash-o"></span></button>
                                </td>
                            </tr>
                        @endforeach

                        </tbody>

                    </table>
                </div><!-- /.box-body -->
            </div><!-- /.box -->
        </div><!-- /.col -->
    </div><!-- /.row -->
@endsection




@section('pages_css')

    <!-- DataTables -->
    <link rel="stylesheet" href="{{ asset('bower_components/AdminLTE/plugins/datatables/dataTables.bootstrap.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animate.css') }}">
    <style>
        .btn-gig-activate:hover {
            background-color: #5cb85c;
            border-color: #4cae4c;
        }
    </style>

@endsection





@section('pages_script')

    <!-- DataTables -->
    <script src="{{ asset('bower_components/AdminLTE/plugins/datatables/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('bower_components/AdminLTE/plugins/datatables/dataTables.bootstrap.min.js') }}"></script>
    <!-- page script -->
    <script>
        $(function () {
            var table = $("#example1").DataTable({
                "aaSorting": []
            });

            $('#example1 tbody').on('click', 'button.btn-del', function() {

                var button = $(this);

                var rowId = button.data('id');

                $.ajax({
                    method: 'DELETE',
                    url: button.data('url'),
                    data: { gig_id: rowId },
                }).done(function(data) {
                    if(data != 0) {
                        //notifyMessage('Gig Deleted Successfully.', 'success');
                        $.notify({
                            // options
                            message: 'Gig Deleted Successfully'
                        },{
                            // settings
                            placement: {
                                from: 'bottom',
                                align: 'right'
                            },
                            type: 'success'
                        });

                        table.row( button.parents('tr') ).remove().draw();

                    } else {
                        //notifyMessage('Gig Deleting failed please try again.', 'danger')
                        $.notify({
                            // options
                            message: 'Gig Deleting failed please try again'
                        },{
                            // settings
                            placement: {
                                from: 'bottom',
                                align: 'right'
                            },
                            type: 'danger'
                        });
                    }
                });

            });

            document.querySelector('.form-gigs-body-container').addEventListener('click', function(e) {

                var clickedElement = e.target;
                var form = e.target.parentNode;
                var formData = new FormData(form);

                clickedElement.setAttribute('disabled', 'disable');

                $.ajax({
                    url: form.action,
                    method: form.method,
                    contentType: false,
                    processData: false,
                    data: formData,
                    success: function(data) {
                        if(data.status == 1) {
                            clickedElement.classList.remove('btn-primary');
                            clickedElement.classList.add('btn-success');
                        } else if(data.status == 0) {
                            clickedElement.classList.remove('btn-success');
                            clickedElement.classList.add('btn-primary');
                        }

                        clickedElement.removeAttribute('disabled');
                    }
                });
            })

        });
    </script>

@endsection