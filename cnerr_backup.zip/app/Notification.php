<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Notification extends Model
{
    protected static $instance = null;

    protected $fillable = [
        'user_id',
        'message',
    ];

    protected $hidden = [
        'id',
        'user_id',
        'updated_at',
    ];

    public static function getInstance()
    {
        if(is_null(self::$instance))
            self::$instance = new self();

        return self::$instance;
    }

    /**
     * @param $userId
     * @param $message
     * @return bool
     */
    public static function sendNotification($userId, $message)
    {
        $notification = self::getInstance();
        $notification->user_id = $userId;
        $notification->message = $message;
        return $notification->save();
    }

    public static function hasNotifications()
    {
        $user = Auth::admin()->get();

        $totalNotifications = self::where(['user_id' => $user->id])->count();

        if($totalNotifications > 0) {
            return true;
        } else {
            return false;
        }
    }

    public static function totalNotifications()
    {
        $user = Auth::admin()->get();
        return $totalNotifications = self::where(['user_id' => $user->id])->count();
    }

    public static function getNotifications()
    {
        $user = Auth::admin()->get();
        return $notifications = self::where(['user_id' => $user->id])->orderBy('created_at', 'desc')->get();
    }
}
