<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Intervention\Image\ImageManager;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\File;
use PhpSpec\Exception\Exception;

class ProfileController extends Controller
{

    public function index(Request $request)
    {
        $data['user'] = Auth::user()->get();

        return view('pages.profile')->with($data);
    }
    
    public function change_profile_image(Request $request)
    {
        if(Input::file())
        {
            $user = Auth::user()->get();
            if(file_exists(public_path('photos/mini/' . basename($user->profile_image))))
            {
                try {
                    unlink(public_path('photos/mini/' . basename($user->profile_image)));
                } catch(\Exception $e) {

                }
            }
            $image = Input::file('profile-img');
            $absolute_path = 'photos/mini/' . $user->username . '.' . time() . '.' . $image->getClientOriginalExtension();
            $relative_path = public_path($absolute_path);

            Image::make($image->getRealPath())->resize(100, 100)->save($relative_path);

            $user->profile_image = url() . '/' . $absolute_path;
            $user->save();
            return url() . '/' . $absolute_path;
        }
        else
        {
            return 'no';
        }
    }
    
    public function change_profile_cover_image(Request $request)
    {
        if(Input::file())
        {
            $user = Auth::user()->get();
            if($user->cover_image != NULL)
            {
                if(file_exists(public_path('photos/cover/' . basename($user->cover_image))))
                {
                    unlink(public_path('photos/cover/' . basename($user->cover_image)));
                } 
            }
            
            $image = Input::file('profile-cover-img');
            $absolute_path = '/photos/cover/' . $user->username . '.cover.' . time() . '.' . $image->getClientOriginalExtension();
            $relative_path = public_path($absolute_path);
            Image::make($image->getRealPath())->resize(1140,250)->save($relative_path);
            $user->cover_image = url() . $absolute_path;
            $user->save();
            return url() . $absolute_path;
        }
        else
        {
            return 'no';
        }
    }
}
