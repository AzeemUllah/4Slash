<?php

namespace App\Http\Controllers;

use App\Gig;
use App\Gigtype;
use App\GigImages;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{

    public function index()
    {
        if(Auth::user()->check()) {
            return redirect()->route('dashboard');
        } else {
            $featuredGigs = Gig::getAllFeaturedGigs();

            foreach ($featuredGigs as $featuredGig) {
                $featuredGig['gigtype_slug'] = Gigtype::where(['id' => $featuredGig->gigtype_id])->first()->slug;
                $featuredGig['thumbnail'] = GigImages::getGigThumbnail($featuredGig->id);

            }

            $data['featuredGigs'] = $featuredGigs;
            return view('pages.home')->with($data);
        }
    }

}
