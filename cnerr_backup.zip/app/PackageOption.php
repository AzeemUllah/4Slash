<?php

namespace App;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class PackageOption extends Model
{
    protected $table = 'packages_options';

    protected $fillable = [
        'option',
        'packages_id'
    ];
}