<?php

namespace App\Http\Controllers;

use App\Agency;
use App\AgencyInvoice;
use Illuminate\Http\Request;

use App\User;
use App\Admin;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;

class AdminAgenciesController extends Controller
{

    public function index()
    {
        $agencies = Admin::where(['type' => 'agency'])->get();

        $data['agencies'] = $agencies;

        return view('pages.admin.agencies')->with($data);
    }

    public function getAgency(Request $request, $agencyEmail) {

        $agency = Agency::where(['type' => 'agency', 'email' => $agencyEmail])->first();
        $pendingOrders = $agency->getPendingOrders();
        $completedOrders = $agency->getCompletedOrders();


        $data['agency'] = $agency;
        $data['agency']['pendingOrders'] = $pendingOrders;
        $data['agency']['completedOrders'] = $completedOrders;
        $data['agency']['agencyInvoices'] = AgencyInvoice::where(['agency_id' => $agency->id])->get();

        return view('pages.admin.agency', $data);

    }

    public function agencyUpdate(Request $request, $agencyEmail) {

        $agency = Agency::where(['type' => 'agency', 'email' => $agencyEmail])->first();

        $data['update'] = true;
        $data['agency'] = $agency;

        return view('pages.admin.agency_create', $data);

    }

    public function putAgencyUpdate(Request $request) {

        $agency = Agency::where(['email' => $request->input('email')])->first();

        $agency->name = $request->input('name');
        $agency->username = $request->input('name');
        $agency->email = $request->input('email');
        $agency->agency_percentage = $request->input('percent');
        $agency->save();

        return redirect()->route('adminagencies');

    }

    public function withdrawAgencyAmount(Request $request) {

        try {
            DB::transaction(function () use ($request)  {

                $agency = User::where(['id' => $request->input('agencyId')])->first();
                $agencyAmount = $agency->wallet;
                $agency->wallet = 0;
                if($agency->save()) {

                    $agencyInvoice = new AgencyInvoice();
                    $agencyInvoice->setDetail('Paid: ' . $agencyAmount . '&euro;');
                    $agencyInvoice->setPaid($agencyAmount);
                    $agencyInvoice->setBalance($agency->wallet);
                    $agencyInvoice->setAgencyId($agency->id);
                    $agencyInvoice->save();

                }

            });

            return redirect()->back();
        } catch(\Exception $e) {
            dd($e);
        }

    }

}
