<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Invoice extends Model
{
    protected $table = 'invoices';

    public function generate($orderId)
    {
        $this->invoice_no = rand(0, 99) . date("dmy") . time();
        $this->order_id = $orderId;
        $this->save();
    }
}
