<?php

namespace App\Http\Controllers;

use App\Gig_addon;
use App\GigImages;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Gigtype;
use App\Gig;
use App\FavouriteGigs;
use App\Gig_question;

use Illuminate\Support\Facades\Auth;
use Session;

class GigController extends Controller
{
    private function getQuestions($questions)
    {
        foreach($questions as $question)
        {
            if($question->type == 'check')
                $question->answers = explode(',', $question->answers);
            else if($question->type = 'range')
                $question->answers = explode(' ', $question->answers);
        }

        return $questions;
    }

    public function index(Request $request, $gigType, $gig)
    {
        $user = Auth::user()->get();

        if(isset($_POST['addToFavourite']))
        {

            $gig = Gig::where(['uuid' => $_REQUEST['funnel']])->first();
            $fg = new FavouriteGigs;
            $fg->gig_id = $gig->id;
            $fg->user_id = $user->id;
            $fg->save();
            
            $totalFavourite = FavouriteGigs::where(['gig_id' => $gig->id])->count();
            
            return $totalFavourite;
        }

        $gigTypee = Gigtype::where('slug', $gigType)->first();
        $gig = Gig::where(['gigtype_id' => $gigTypee->id, 'slug' => $gig, 'uuid' => $request->input('funnel')])->first();


        Session::put('order_gig', $gig);

        if(Auth::user()->check()) {
            $favourite = FavouriteGigs::where(['user_id' => $user->id, 'gig_id' => $gig->id])->first();
            if (is_object($favourite)) {
                $gig->favourite = true;
            } else {
                $gig->favourite = false;
            }
        }


        $totalFavourite = FavouriteGigs::where(['gig_id' => $gig->id])->count();
        $gig->totalFavourite = $totalFavourite;


        $questions =  Gig_question::where('gig_id', $gig->id)->get();
        $gig_addons = Gig_addon::where(['gig_id' => $gig->id])->get();
        $gig_images = GigImages::where(['gig_id' => $gig->id])->get();


        $data['questions'] = $this->getQuestions($questions);
        $data['gigType'] = $gigTypee;
        $data['gig'] = $gig;
        $data['gig_addons'] = $gig_addons;
        $data['gig_images'] = $gig_images;

        return view('pages.gig')->with($data);
    }

    public function favourite(Request $request) {
        return ['favourite' => Gig::favourite($request->input('gig-id'))];
    }

}
