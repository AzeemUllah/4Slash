@include('includes.header')


        <!-- content -->
<div style="background-color: #f1f2f2;">
    <div class="container main-body">
        <h1 class="first-head">{{ $gig->title }}</h1>

        <div class="row">
            <form id="gigPurchaseForm" method="post" action="{{ route('payment') }}">

                <div class="col-md-7 col-sm-12">
                    <div class="slider" style="width: 100%;">
                        <div class="single-item" style="margin-bottom:0px;">
                            @foreach($gig_images as $gig_image)
                            <div class="slide">
                                <div class="back">
                                    <img style="height:310px;width:475px;" src="{{ url('files/gigs/images') . '/' . $gig_image->image }}">
                                </div>
                            </div>
                            @endforeach
                        </div>
                        <div class="multiple-items" style="background-color:rgb(227, 227, 227);">
                            @foreach($gig_images as $gig_image)
                            <div class="slide">
                                <img src="{{ url('files/gigs/images') . '/' . $gig_image->image }}" style="height:60px; border:2px solid #2f8dd7;">
                            </div>
                            @endforeach
                        </div>
                    </div>


                    <div class="left-para" style="border-top:2px solid #c6c6c6; margin-top:15px;">
                        <h1>What you get with this <b>GIG</b></h1>

                        {{--<p>{{htmlentities($gig->discription) }}</p>--}}


                        <div>
                            <?php
                                $doc = new DOMDocument();
                                $doc->loadHTML($gig->discription);
                                echo $doc->saveHTML();
                            ?>
                        </div>

                        {{--<div class="buttons">--}}
                            {{--<button class="btn btn-primary"><span class="glyphicon glyphicon-pencil"></span>Contact with Me--}}
                            {{--</button>--}}
                                {{--<button onclick="showGigPurchase()" type="button" id="btn-get-this-gig" class="btn btn-primary"><span><img src="{{ asset('img/cakwe.png') }}"></span>Get this GIG</button>--}}
                        {{--</div>--}}
                        <br>























































                    </div>

























                </div>

                <div class="col-md-5 col-sm-12  right-panel">

                    <div class="text-center order-basic-info">
                        {{--<h1 class="f-head"><span>Basic Gig Price</span>{{ config('app.currency') }}{{ $gig->price }}</h1>--}}
                        <div class="gig-final-cost" style="margin: 0 auto;margin-bottom: 10px;margin-top: 5px;">
                            <div style=" font-size: 50px;">{{ config('app.currency') }}<span class="gig-final-cost-amount">{{ $gig->price }}</span></div>
                        </div>
                        <div class="buttons">
                            {{--<button class="btn btn-primary"><span class="glyphicon glyphicon-pencil"></span>Contact with Me--}}
                            {{--</button>--}}
                            <button onclick="showGigPurchase()" type="button" class="btn btn-primary btn-get-this-gig"><span></span>jetzt bestellen</button>
                        </div>








                        <div class="well" id="company-info-block">

                            <p class="comp-desc">Projektbeschreibung</p>

                            <div class="row">
                                <div class="col-md-12">

                                    @foreach($questions as $question)
                                        <hr>
                                        <div class="row">
                                            <div class="col-lg-12">

                                                <p class="no-color-class">{{  $question->question }}</p>

                                                @if($question->type == 'check')

                                                    <div class="row text-center">
                                                        @foreach($question->answers as $answer)
                                                            <div class="col-sm-3">
                                                                <div class="checkbox checkbox-info checkbox-circle">
                                                                    <input id="{{ str_replace(" ", "-", strtolower($answer)) }}"
                                                                           class="styled" value="{{ $answer }}" type="radio" name="question[{{ $question->id }}]">
                                                                    <label for="{{ str_replace(" ", "-", strtolower($answer)) }}"
                                                                           style="margin-left:25px; margin-bottom:10px;">

                                                                    </label>

                                                                    <div><p class="font-family-color">{{ $answer }}</p></div>
                                                                </div>
                                                            </div>
                                                        @endforeach
                                                    </div>

                                                @elseif($question->type == 'range')
                                                    <table class="ranges">
                                                        @foreach($question->answers as $answer)
                                                            <?php $options = explode(',', $answer); ?>


                                                            <tr>
                                                                <td>{{ $options[0] }}</td>
                                                                <td><input name="{{ $question->id }}[]" class="ex1" data-slider-id='ex1Slider' type="text" data-slider-min="0" data-slider-max="10" data-slider-step="1" data-slider-value="0"/></td>
                                                                <td class="classic">{{ $options[1] }}</td>
                                                            </tr>


                                                        @endforeach
                                                    </table>
                                                @endif

                                            </div>
                                        </div>


                                    @endforeach





                                    <div style="display:none;" class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <input value="test" required name="company_name" type="text" class="form-control" placeholder="Comapny Name">
                                            </div>
                                        </div>
                                    </div>
                                    <div style="display:none;" class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <input value="test" required name="company_tagline" type="text" class="form-control" placeholder="Tagline">
                                            </div>
                                        </div>
                                    </div>
                                    <div style="display:none;" class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <input value="test" required name="company_industry" type="text" class="form-control" placeholder="Industry">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <textarea required name="company_discription" class="form-control" rows="5" placeholder="Bemerkung" id="comment"></textarea>
                                            </div>
                                        </div>
                                    </div>


                                    {{--<input type="hidden" name="total_order_amount" value="{{ $total_order_amount }}">--}}




                                    <button id="btn-pay-start" type="button" class="btn btn-primary" style="border-radius: 6px;">
                                        Jetzt kaufen
                                    </button>
                                    {{--<button type="submit" class="btn btn-primary" style="width: 100px; border-radius: 6px;">Pay & Start</button>--}}

                                    <div id="paymentConfirmationModal" class="modal fade bs-example-modal-sm paypal" tabindex="-1" role="dialog"
                                         aria-labelledby="mySmallModalLabel">
                                        <div class="modal-dialog modal-md">
                                            <div class="modal-content">
                                                <div class="modal-header login-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                                                aria-hidden="true">&times;</span></button>
                                                </div>
                                                <div class="modal-body">
                                                    <table class="order-view">
                                                        <thead>
                                                        <tr>
                                                            <th class="text-center" colspan="2">GIG</th>
                                                        </tr>
                                                        <tr>
                                                            <th>Gig</th>
                                                            <th>Amount</th>
                                                        </tr>
                                                        </thead>
                                                        <tbody>
                                                        <tr>
                                                            <td>{{ $gig->title }}</td>
                                                            <td>{{ config('app.currency') }}<span class="gig-amount">{{ $gig->price }}</span></td>
                                                        </tr>
                                                        </tbody>
                                                    </table>

                                                    <br>

                                                    <table class="order-view order-view-addon">
                                                        <thead>
                                                        <tr>
                                                            <th class="text-center" colspan="4">ADDONS</th>
                                                        </tr>
                                                        <tr>
                                                            <th>Addon</th>
                                                            <th>Amount</th>
                                                            <th>Quantity</th>
                                                            <th>Total Amount</th>
                                                        </tr>
                                                        </thead>
                                                        <tbody>
                                                        </tbody>
                                                    </table>

                                                    <br>

                                                    <table class="order-view">
                                                        <tbody>
                                                        <tr>
                                                            <td>Processing Fees 5%</td>
                                                            <td><span id="processingFees" class="pull-right">&euro; 0</span></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Taxes Included 19%</td>
                                                            <td><span id="taxIncluded" class="pull-right">&euro; 0</span></td>
                                                        </tr>
                                                        <tr>
                                                            <td><h5>Total Amount</h5></td>
                                                            <td><h5><span class="pull-right total-grand-order-amount">0</span></h5></td>
                                                        </tr>
                                                        </tbody>
                                                    </table>
                                                </div>


                                                <button type="submit" class="btn btn-primary btn-lg"
                                                        style="border-radius: 6px; margin-bottom:40px;">Pay with PayPal
                                                </button>
                                            </div>
                                        </div>
                                    </div> <!-- modal -->
                                </div>
                            </div>
                        </div>










                        <h1 class="s-head"><span class="glyphicon glyphicon-time clock"></span>“ Lieferung in  {{ $gig->delivery_days }} Tagen</h1>

                        <div class="row">
                            <div class="button col-md-12 col-sm-12 col-xs-12">
                                    <button <?= ($gig->favourite) ? 'disabled' : '' ?> id="btn-favourite-submit" type="button" class="btn btn-default right-btn" data-toggle="tooltip" data-placement="right">
                                        <i class="fa fa-heart-o" style="margin-right:5px; color:#ff9492;">
                                        </i>
                                        Favorit (<span class="totalFavourite">{{ $gig->totalFavourite }}</span>)
                                    </button>
                            </div>
                        </div>
                    </div>

                    <div class="right-para text-left">
                        <h1 class="right-addon-head">Add-<b>Ons</b></h1>

                        <div class="addons">
                            @foreach($gig_addons as $gig_addon)
                                <div class="form-group row first-addon">
                                    <div class="checkbox checkbox-info checkbox-circle chck-bx2 col-md-8">
                                        <input id="checkbox12" class="styled radio-btn-addon" type="checkbox">
                                        <label for="checkbox12">
                                            <p class="chck-bx-p addon-name">{{ $gig_addon->addon }}</p>
                                        </label>
                                    </div>
                                    <div class="col-md-4 select">
                                        <select data-addon-id="{{ $gig_addon->id }}" class="selectpicker select-addon">
                                            @for($i = 1; $i <= 10; $i++)
                                                <option data-amount="{{ $gig_addon->amount * $i }}" value="{{ $i }}">{{ $i }} ({{ config('app.currency') }}{{ $gig_addon->amount * $i }})</option>
                                            @endfor
                                        </select>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>





                </div>

            </form>
        </div>
</div>
</div>

@include('includes.footer')

<script>

    function showGigPurchase() {
        $('#company-info-block').slideToggle();
    }

    (function() {
        $('#gigPurchaseForm').validate();

        document.querySelector('#btn-pay-start').addEventListener('click', function(e) {

            if($('#gigPurchaseForm').valid()) {
                $('#paymentConfirmationModal').modal('show');
            }

        });

        document.querySelector('#btn-favourite-submit').addEventListener('click', function() {
            $.ajax({
                url: window.location,
                method: 'post',
                data: { addToFavourite: true },
                success: function(data)
                {
                    var totalFavourite = document.querySelector('.totalFavourite');
                    totalFavourite.innerHTML = data;
                    document.querySelector('#btn-favourite-submit').setAttribute('disabled', 'disabled');
                }
            });
        });

        document.querySelector('#btn-pay-start').addEventListener('click', function() {

            document.querySelector('.order-view-addon tbody').innerHTML = "";
            var radio = document.querySelectorAll('.radio-btn-addon');

            if(radio.length > 0)
            {
                var select = document.querySelectorAll('select.select-addon');
                var addonName = document.querySelectorAll('.addon-name');
                var gigAmount = parseFloat(document.querySelector('.gig-amount').textContent);
                var totalAddonsAmount = 0;

                [].forEach.call(radio, function (elem, index, arr) {
                    if (elem.checked)
                    {
                        if(select[index].value != "")
                        {
                            select[index].name = 'addon[' + select[index].getAttribute('data-addon-id') + ']';


                            var row = document.createElement('tr');
                            var col1 = document.createElement('td');
                            col1.textContent = addonName[index].textContent;
                            var col2 = document.createElement('td');
                            col2.innerHTML = currencyType + "<span>" + select[index].firstElementChild.getAttribute('data-amount') + "</span>";
                            var col3 = document.createElement('td');
                            col3.textContent = (parseInt(select[index].selectedIndex) + 1);
                            var col4 = document.createElement('td');
                            var totalAddonAmount = (parseFloat(col2.firstElementChild.textContent) * parseFloat(col3.textContent));
                            col4.textContent = currencyType + totalAddonAmount;
                            totalAddonsAmount += totalAddonAmount;

                            row.appendChild(col1);
                            row.appendChild(col2);
                            row.appendChild(col3);
                            row.appendChild(col4);

                            document.querySelector('.order-view-addon tbody').appendChild(row);
                        }
                    }
                });



                var totalOrderAmount = (totalAddonsAmount + gigAmount);
                var processingFees = ((totalOrderAmount * 5) / 100);
                var taxIncluded = (((totalOrderAmount + processingFees) * 19) / 100);

                document.querySelector('#taxIncluded').textContent = currencyType + taxIncluded;
                document.querySelector('#processingFees').textContent = currencyType + processingFees;
                document.querySelector('.total-grand-order-amount').textContent = currencyType + (totalOrderAmount + processingFees);
            }
        });

        document.querySelector('.addons').addEventListener('click', function(e) {
                var radio = document.querySelectorAll('.radio-btn-addon');
                if (radio.length > 0) {
                    var select = document.querySelectorAll('select.select-addon');
                    var gigAmount = parseFloat(document.querySelector('.gig-amount').textContent);
                    var totalAddonsAmount = 0;

                    [].forEach.call(radio, function (elem, index, arr) {
                        if (elem.checked) {
                            if (select[index].value != "") {
                                var addonAmount = select[index].firstElementChild.getAttribute('data-amount');
                                var addonQuantity = (parseInt(select[index].selectedIndex) + 1);
                                var totalAddonAmount = (parseFloat(addonAmount) * parseFloat(addonQuantity));
                                totalAddonsAmount += totalAddonAmount;
                            }
                        }
                    });

                    document.querySelector('.gig-final-cost-amount').textContent = (totalAddonsAmount + gigAmount);
                }
        });

        $('[data-toggle="tooltip"]').tooltip();

        $('.single-item').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: true,
            fade: true,
            asNavFor: '.multiple-items',
            prevArrow: "<div class=\"slid-prev\"></div>",
            nextArrow: "<div class=\"slid-next\"></div>",
        });

        $('.multiple-items').slick({
            infinite: true,
            slidesToShow: 5,
            slidesToScroll: 4,
            arrows: false,
            asNavFor: '.single-item',
            focusOnSelect: true,
            centerMode: true,
            centerPadding: '15px',
        });
    })();
</script>

</body>
</html>