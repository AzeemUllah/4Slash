<?php

namespace App\Http\Controllers;

use App\CnerrPayment;
use App\CnerrPayments;
use App\Gig_addon;
use App\Notification;
use App\Order;
use App\OrderQuestionAnswer;
use App\Package;
use App\User;
use Carbon\Carbon;
use Faker\Provider\Uuid;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Gig_question;
use App\Gig;
use App\Gigtype;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\URL;
use PayPal\Api\Item;
use PayPal\Api\ItemList;

class OrderController extends Controller
{

    private function getQuestions($questions) {

        foreach($questions as $question) {
            if($question->type == 'check')
                $question->answers = explode(',', $question->answers);
            else if($question->type = 'range') {
                $question->answers = explode(' ', $question->answers);
            }
        }

        return $questions;
    }

    private function getOrderAddons($request) {

        $addons_response = $request->except(['funnel']);

        $addons['addons'] = [];
        $addons['total_addons_amount'] = 0;

        foreach($addons_response as $key => $value) {
            if(!empty($request->input($key))) {
                $addon = Gig_addon::where(['id' => $key])->first();
                $addon['quantity'] = $value;
                $addon['total_amount'] = $addon->amount * $value;

                $addons['total_addons_amount'] = ((int)$addons['total_addons_amount']) + ((int)$addon->amount * $value);
                array_push($addons['addons'], $addon);
            }
        }

        return $addons;

    }

    public function index(Request $request, $gigType, $gig)
    {
        $gigTypee = Gigtype::where('slug', $gigType)->first();
        $gig = Gig::where(['gigtype_id' => $gigTypee->id, 'slug' => $gig, 'uuid' => $request->input('funnel')])->first();
        $questions =  Gig_question::where('gig_id', $gig->id)->get();

        $order_addons = $this->getOrderAddons($request);

        Session::put('order_gig', $gig);
        Session::put('order_addons', $order_addons);

        $data['questions'] = $this->getQuestions($questions);
        $data['order_addons'] = $order_addons;
        $data['gig'] = $gig;
        $data['total_order_amount'] = ((int)$order_addons['total_addons_amount']) + ((int)$gig->price);
        
        return view('pages.order')->with($data);
    }

    public function createOrder(Request $request) {

        $gig = Session::get('order_gig');
        $user = Auth::user()->get();



        DB::transaction(function() use ($request, $gig, $user) {


            $order_info = Session::get('order_info');
            $questions = Session::get('questions');



            $order = new Order;
            $order->uuid = \Webpatser\Uuid\Uuid::generate(4);
            $order->order_no = date("Ymd") . strtoupper(substr(uniqid(sha1(time())),0,4));
            $order->gig_id = $gig->id;
            $order->gig_owner_id = $gig->user_id;
            $order->user_id = $user->id;
            $order->company_name = $order_info['company_name'];
            $order->company_tagline = $order_info['company_tagline'];
            $order->company_industry = $order_info['company_industry'];
            $order->company_discription = $order_info['company_discription'];
            $order->type = 'gig';
            $order->amount = Session::get('total_order_amount');
            $order->expiry = Carbon::now()->addDays(((int)$gig->delivery_days));
            $order->save();

         


//            foreach($questions as $key => $value) {
//
//                    $orderQuestionAnswer = new OrderQuestionAnswer;
//                    $orderQuestionAnswer->gig_question_id = (int)$key;
//                    $orderQuestionAnswer->order_id = (int)$order->id;
//                    $orderQuestionAnswer->answers = $value;
//                    $orderQuestionAnswer->save();
//
//            }


        });

        Session::forget('order_gig');
        Session::forget('order_addons');
        Session::forget('order_info');

        return redirect()->route('myorders');

    }

    public function createCustomOrder(Request $request) {

//        if(Order::createCustomOrder(
//            $request->input('comp-name'),
//            $request->input('comp-email'),
//            $request->input('comp-tel'),
//            $request->input('comp-site'),
//            $request->input('comp-extra-note')
//        )) {
//            return ['status' => true];
//        } else {
//            return ['status' => false];
//        }

        if(Order::createCustomOrder($request)) {
            return ['status' => true];
        } else {
            return ['status' => false];
        }

    }

    public function createPackageOrder(Request $request) {


        $package = Package::where(['packages_id' => $request->input('package-id')])->first();
        Session::put('package', $package);

        $itemsList = new ItemList();


        $item = new Item();
        $item->setName('Package: ' . $package->title)
            ->setCurrency('EUR')
            ->setQuantity(1)
            ->setPrice($package->price);
        $itemsList->addItem($item);


        $cnerrPayments = new CnerrPayments();
        $paymentURL = $cnerrPayments->makePaypalPayment($itemsList, URL::route('order.confirm', ['orderType' => 'package']));

        if($paymentURL) {
            Session::put('cnerrPayments', $cnerrPayments);
            return redirect($paymentURL);
        } else {
            return redirect()->back();
        }

    }

    public function confirmOrder(Request $request, $orderType) {


        if(empty(Input::get('PayerID')) || empty(Input::get('token'))) {

            return redirect()->route('dashboard');

        }

        $cnerrPayments = Session::get('cnerrPayments');
        Session::forget('cnerrPayments');


        if($cnerrPayments->confirmPaypalPayment(Input::get('PayerID'))) {


            if($orderType == 'package') {
                $package = Session::get('package');
                Session::forget('package');

                $order = new Order();
                $order->uuid = \Webpatser\Uuid\Uuid::generate(4);
                $order->user_id = Auth::user()->get()->id;
                $order->order_no = date("Ymd") . strtoupper(substr(uniqid(sha1(time())),0,4));
                $order->type = 'package';
                $order->amount = $package->price;
                $order->packages_id = $package->packages_id;
                $order->save();

                $admin = User::where(['type' => 'admin'])->first();

                Notification::sendNotification($admin->id, '<a href="'. route('myorders') .'">You have a new Package order</a>');

                return redirect()->route('myorders');
            }

        }


        return redirect()->route('dashboard');

    }

}