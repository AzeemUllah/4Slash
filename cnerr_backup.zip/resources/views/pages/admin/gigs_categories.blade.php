@extends('pages.admin.admin_template')


@section('header_title')

    <h1>Gigs Categories</h1>

@endsection




@section('content')

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header text-right">
                    <a href="{{ route('admingigscategoriescreate') }}" class="btn btn-primary btn-sm"><span class="fa fa-plus"></span></a>
                </div><!-- /.box-header -->
                <div class="box-body">
                    <table id="table-gig-category" class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>Title</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($gigs_categories as $gig_category)
                            <tr>
                                <td>{{ $gig_category->name }}</td>
                                <td>
                                    <form class="form-gig-category-delete" method="post" action="{{ route('admingigscategoriesdelete') }}">
                                        <input type="hidden" name="gig-category-id" value="{{ $gig_category->id }}">
                                        <a href="{{ route('admingigscategoriescreate') . '?id=' . $gig_category->id . '&action=update' }}" class="btn btn-default btn-xs"><span class="fa fa-pencil"></span></a>
                                        <button type="button" class="btn btn-danger btn-xs fa fa-trash-o"></button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach

                        </tbody>

                    </table>
                </div><!-- /.box-body -->
            </div><!-- /.box -->
        </div><!-- /.col -->
    </div><!-- /.row -->


@endsection



@section('pages_script')
    <script>
        (function() {
                document.querySelector('#table-gig-category').addEventListener('click', function (e) {
                    if(e.srcElement.nodeName == 'BUTTON') {
                        var form = e.srcElement.parentNode;
                        var formData = new FormData(form);

                        $.ajax({
                            url: form.action,
                            method: 'post',
                            data: formData,
                            contentType: false,
                            processData: false,
                            complete: function (data) {
                                if (JSON.parse(data.responseText).deleted) {
                                    $(form).parent().parent().remove();
                                    $.notify({
                                        // options
                                        message: 'Gig Category Delete Successfully.'
                                    }, {
                                        // settings
                                        placement: {
                                            from: 'bottom',
                                            align: 'right'
                                        },
                                        type: 'success'
                                    });
                                }
                                else {
                                    $.notify({
                                        // options
                                        message: 'Gig Category Deleting failed please try later.'
                                    }, {
                                        // settings
                                        placement: {
                                            from: 'bottom',
                                            align: 'right'
                                        },
                                        type: 'danger'
                                    });
                                }
                            }
                        });
                    }
                });

        })();
    </script>
@endsection