<?php

namespace App\Http\Controllers;

use App\Gig;
use App\Gig_addon;
use App\Gig_question;
use App\GigImages;
use App\Gigtype;
use App\Gigtype_Subcategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Redirect;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class AdminGigsController extends Controller
{

    public function index()
    {
        $gigs = Gig::orderBy('created_at', 'desc')->get();

        $data['gigs'] = $gigs;
        return view('pages.admin.gigs')->with($data);
    }

    public function create(Request $request) {

        $update = false;

        if($request->input('action')) {
            if($request->input('action') == 'update') {

                $update = true;

                $gig = Gig::where(['uuid' => $request->input('funnel')])->first();

                $data['update'] = $update;
                $data['categories'] = Gigtype::all();
                $data['subCategories'] = Gigtype_Subcategory::where(['gigtypes_id' => $gig->gigtype_id])->get();
                $data['gig'] = $gig;
                $data['gigAddons'] = Gig_addon::where(['gig_id' => $gig->id])->get();
                $data['gigQuestions'] = Gig_question::where(['gig_id' =>$gig->id])->get();
                $data['gigImages'] = GigImages::where(['gig_id' => $gig->id])->get();
                return view('pages.admin.gigs_create')->with($data);
            }
        }


        $categories = Gigtype::all();

        $data['update'] = $update;
        $data['categories'] = $categories;

        return view('pages.admin.gigs_create')->with($data);

    }

    public function createGig(Request $request) {


        $user = Auth::admin()->get();

        DB::transaction(function() use($request, $user) {

            $gig = Gig::create([

                'uuid' => \Webpatser\Uuid\Uuid::generate(4),
                'user_id' => $user->id,
                'gigtype_id' => $request->input('gig-category'),
                'slug' => str_replace(' ', '_', strtolower($request->input('gig-title'))),
                'title' => $request->input('gig-title'),
                'short_discription' => $request->input('gig-short-discription'),
                'discription' => $request->input('gig-discription'),
                'delivery_days' => $request->input('gig-delivery-days'),
                'price' => $request->input('gig-price'),

            ]);

            $images = $request->file('gig-images');
            if(count($images) > 0)
            {

                foreach($images as $image)
                {
                    if(!empty($image)) {
                        dd($image);
                        $movedImage = $image->move(public_path('files/gigs/images/'), $image->getClientOriginalName());
                        $gigImage = new GigImages();
                        $gigImage->image = $image->getClientOriginalName();
                        $gigImage->gig_id = $gig->id;
                        $gigImage->save();
                    }
                }
            }

            if(count($request->input('gig-addon')) > 0) {
                foreach ($request->input('gig-addon') as $gig_add) {
                    Gig_addon::create([

                        'gig_id' => $gig->id,
                        'addon' => $gig_add['discription'],
                        'amount' => $gig_add['price'],

                    ]);
                }
            }

            if(count($request->input('gig-choice-question')) > 0) {
                foreach ($request->input('gig-choice-question') as $gig_choice_quest) {

                    Gig_question::create([

                        'gig_id' => $gig->id,
                        'question' => $gig_choice_quest['question'],
                        'answers' => implode(',', $gig_choice_quest['answers']),
                        'type' => 'check',

                    ]);
                }
            }

        });

        return redirect()->route('admingigs');

    }

    public function deleteGig(Request $request) {

        $gig = Gig::destroy($request->input('gig_id'));

        return $gig;

    }


}
