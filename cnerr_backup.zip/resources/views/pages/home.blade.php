<!DOCTYPE html>
<html>
<head>
<title>Cnerr</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="js/jquery-1.11.3.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/cnerr-app.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,500,600,700,800,900,200,300,100' rel='stylesheet'
          type='text/css'>
    <link rel="stylesheet" type="text/css" href="{{ asset('css/O-style.css') }}">

    <link rel="stylesheet" href="css/Z-style.css">
    <link rel="stylesheet" href="css/bootstrap-social.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
</head>
<body ng-app="cnerr">
<div id="fb-root"></div>
<script>(function (d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s);
        js.id = id;
        js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>

<script>
    $(document).ready(function(){
        $('.form-btn').click(function(){
            $('.gig-style').css('display', 'none');
        });
    })
</script>

@include('pages.partials.fiverr-components.header-nav')

<div class="cnerr-background-image">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <nav class="navbar cnerr-navbar">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed mob-nav" data-toggle="collapse"
                                data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar" style="background-color:white;"></span>
                            <span class="icon-bar" style="background-color:white;"></span>
                            <span class="icon-bar" style="background-color:white;"></span>
                        </button>
                        <a class="navbar-brand" href=""></a>
                    </div>
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse border-none" id="bs-example-navbar-collapse-1">
                        {{--<ul class="nav navbar-nav navbar-right index-navbar">--}}
                        {{--<li><a href="#" data-toggle="modal" data-target="#gridSystemModal">Einloggen</a></li>--}}
                        {{--<li><span class="cnerr-navbar-bar hidden-xs hidden-sm">|</span></li>--}}
                        {{--<li><a href="#" data-toggle="modal" data-target="#gridSystemModal1">Registrieren</a></li>--}}
                        {{--</ul>--}}
                    </div><!-- /.navbar-collapse -->
                </nav>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 cnerr-logo-margin-top">
                <div class="row">
                    <img src="img/logo.png">
                </div>
                <div class="row">
                    <p class="cnerr-slider-para">Was benötigst du? Auf Cnerr bekommst du es! </p>

                    <form method="get" action="{{ route('gigs') }}">
                        <div style="border-radius:5px;height: 60px;margin-bottom: 25px;padding: 5px;background-color: black;display:flex;flex-direction:row;">
                            <div style="flex-grow:1;margin-right:5px;"><input name="search"
                                                                              placeholder="Hier kannst du Produkte suchen..."
                                                                              type="text"
                                                                              style="font-size:20px;font-weight:bold;width: 100%;height: 50px;">
                            </div>
                            <div>
                                <button type="submit" class="btn btn-primary"
                                        style="background-color:#008FD5;height: 50px;">Find Services
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="row">
                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 left-img">
                        <a href="#"><img src="img/appstore.png" class="img-responsive"></a>
                    </div>
                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 left-img">
                        <a href="#"><img src="img/googlestore.png" class="img-responsive"></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <img src="img/hand-phone.png" class="cnerr-hand-image hidden-xs hidden-sm">
            </div>
        </div>
    </div>
</div>
<div class="cnerr-main-content-background-color text-center">
    <div class="container">













        @if($featuredGigs->count() > 0)
            <div>
                <h1>Ausgewählte Katagorien</h1>
                <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12 c-top-head-gigs">
            <div class="c-gig-box">
                <a href="/gigs/graphic_&_design_">
                    <p><strong>Graphic & Design</strong></p>
                    <p></p>
                    <img src="img/graphics_design1.png" alt="" width="100%">
                </a>
            </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12 c-top-head-gigs">
            <div class="c-gig-box">
                <a href="/gigs/online_marketing">
                    <p><strong>Online Marketing</strong></p>
                    <p></p>
                    <img src="img/online_marketing1.png" alt="" width="100%">
                </a>
            </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12 c-top-head-gigs">
            <div class="c-gig-box">
                <a href="/gigs/programming_&_tech">
                    <p><strong>Proramming & Tech</strong></p>
                    <p></p>
                    <img src="img/programming_tech1.png" alt="" width="100%">
                </a>
            </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12 c-top-head-gigs">
            <div class="c-gig-box">
                <a href="/gigs/video_&_animation">
                    <p><strong>Video & Animation</strong></p>
                    <p></p>
                    <img src="img/video_animation1.png" alt="" width="100%">
                </a>
            </div>
        </div>
        </div><!-------row--------->
            </div><!-------div--------->

        <div class="mp-box mp-box-center-flex">

                <article class="mp-gig-carousel">

                    <header>
                        <h2>


                            Aktuelle Gigs

                        </h2>
                    </header>

                    <div class="gig-carousel cf loading-dummy dummy-12"
                         data-json-path="/gigs/endless_page_as_json?host=homepage&amp;type=endless&amp;category_id=99912&amp;limit=12"
                         data-load-more="false" data-hide-empty="true" data-hide-parent="false" data-gigs-shown="4"
                         data-do-sliding="false" data-two-lines="false" data-do-lazyload="false" data-do-endless="false"
                         data-host="homepage" data-box-id="hp99912_1_4">


                        <div class="slider-box">
                            <div class="slider-hider cf">

                                @foreach($featuredGigs as $featuredGig)
                                    <div class="slide gig-item gig-item-default js-slide js-gig-card "
                                         data-gig-id="4864637"
                                         data-cached-slug="create-unusual-illustrations-in-my-style" data-gig-index="0"
                                         data-gig-category="graphics-design"
                                         data-gig-sub-category="digital-illustration" data-gig-price="20" itemscope=""
                                         itemtype="http://schema.org/Product">


                                        <div class="gig-seller">
                        <span itemprop="aggregateRating" itemscope="" itemtype="http://schema.org/AggregateRating">
                            <span class="ratings-count" itemprop="ratingCount">(202)</span>
                        </span>
                                            <meta itemprop="worstRating" content="1">
                                            <span class="circ-rating-s8 rate-10" itemprop="ratingValue">10</span>
                                            <meta itemprop="bestRating" content="10">
                                            {{--by <a href="/muravski" rel="nofollow" class="seller-name" itemprop="brand" itemscope="" itemtype="http://schema.org/Brand">muravski</a>--}}
                                        </div>

                                        <a href="{{ url() }}/gigs/{{ $featuredGig['gigtype_slug'] }}/{{ $featuredGig->slug }}?funnel={{ $featuredGig->uuid }}"
                                           class="gig-link-main" itemprop="url">
                                            <span class="gig-pict-222" itemscope=""
                                                  itemtype="http://schema.org/ImageObject"><img
                                                        src="{{ $featuredGig['thumbnail'] }}" alt="{{ $featuredGig->title }}"></span>

                                            <h3 itemprop="name">{{ $featuredGig->title }}</h3>
                                        </a>

                                        <aside class="card-badges cf">

                                            <span class="gig-badges featured" itemprop="award">featured</span>

                                        </aside>


                                        <div class="gig-sub cf">


                                            <a href="/muravski/create-unusual-illustrations-in-my-style?context=old.cat_99912&amp;context_type=auto&amp;pos=1&amp;funnel=499168c7-6bda-4234-9ca1-1758feff76ae"
                                               class="gig-price" rel="nofollow" itemprop="offers" itemscope=""
                                               itemtype="http://schema.org/Offer">
                                                <small itemprop="price"></small>
                                                <span itemprop="price">{{ config('app.currency') . $featuredGig->price }}</span></a>

                                            <aside class="gig-collect js-gig-collect" id="coll-gig-4864637"
                                                   data-coll-id="4864637">
                                                {{--<a class="icn-heart-toggle hint--top js-gtm-event" href="#" data-hint="Save in..." data-coll-gig="coll-gig-4864637" data-gtm-action="hp-clicked-list" data-gtm-event="collections"><span></span></a>--}}
                                                @if(\Illuminate\Support\Facades\Auth::user()->check())
                                                    <a class="icn-heart hint--top js-gtm-event" href="#"
                                                       data-hint="Favorite" data-gtm-action="hp-clicked-heart"
                                                       data-gtm-event="collections"><span></span></a>
                                                @endif
                                            </aside>


                                        </div>

                                    </div>
                                @endforeach

                            </div>
                        </div>

                    </div>


                </article>

        </div>
        @endif

        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <h2 class="cnerr-main-content-heading margin-top">Grafik, Design oder Apps? Natürlich auf <span
                            class="txt-color">Cnerr!</span></h2>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <p class="cnerr-main-content-paragragh margin-bottom-top">Benötigst du Designer, Grafiker, kreative Arbeiten, Web- und App-Programmierer oder andere Entwickler? <strong>Cnerr hat die Experten!</strong> </p>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <img src="img/setting.png" class="image-top-margin">

                <p class="img-caption top-bottom-margin">Kreativität</p>

                <p class="cnerr-main-content-paragragh-cat">Nutze unsere Kreativät und Erfahrungen, um dein Produkt wahr werden zu lassen. Unsere Experten verfügen über jahrelange Erfahrungen und werden diese in deinem Produkt einfließen lassen.</p>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <img src="img/document.png" class="image-top-margin">

                <p class="img-caption top-bottom-margin">Professionalität</p>

                <p class="cnerr-main-content-paragragh-cat">Wir arbeiten in unserem Netzwerk ausschließlich mit professionellen Partnern zusammen. Unseren hohen Anspruch an das Produkt lassen wir vor Übermittlung durch die Qualitätskontrolle überprüfen. Erst dann liefern wir die Bestellungen aus.</p>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <img src="img/bulb.png" class="image-top-margin">

                <p class="img-caption top-bottom-margin">Zuverlässigkeit</p>

                <p class="cnerr-main-content-paragragh-cat">Jedes Produkt auf unserem Marktplatz hat eine bestimmte Lieferzeit, die der Kunde mit beeinflussen kann. Die Auslieferung erfolgt garantiert innerhalb des gewünschten Termins.</p>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <img src="img/world.png" class="image-top-margin">

                <p class="img-caption top-bottom-margin">Keinerlei Risiko</p>

                <p class="cnerr-main-content-paragragh-cat">Sollten Sie mit der kreativen Arbeit einmal nicht 100%zig zufrieden sein, werden wir Ihnen den Kaufpreis erstatten. Somit haben Sie auf Cnerr keinelei Risiko.</p>
            </div>
        </div>
    </div>
</div>
<div class="cnerr-public-topcontent-background-color text-center">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <h2 class="cnerr-public-topcontent-heading margin-top">“Cnerr erledigt zuverlässig unsere Arbeiten”</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <p class="cnerr-public-topcontent-paragragh"><b>Dr.Alexander Schuller, </b><span class="designation-color"> Zahnarzt, Niederlande</span>
                </p>
            </div>
        </div>
    </div>
</div>
<div class="cnerr-public-background-color">
    <img src="img/publicimage.jpg" width="100%">
</div>
<div class="cnerr-social-background-color text-center">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <h2 class="cnerr-social-heading margin-top">Sei ein Teil von Cnerr. Wir freuen uns.</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <p class="cnerr-social-paragragh top-bottom">Registriere dich kostenlos und stöbere einfach auf unserem Marktplatz.</p>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <span><a href="https://twitter.com/Cnerr_" target="_blank"><img src="img/icon.png"
                                                                                class="img-responsive"
                                                                                hspace="2"></a></span>
                <span><a href="https://www.facebook.com/cnerr" target="_blank"><img src="img/icon1.png"
                                                                                    class="img-responsive"
                                                                                    hspace="2"></a></span>
                <span><a href="https://de.linkedin.com/in/cnerr" target="_blank"><img src="img/icon3.png"
                                                                                      class="img-responsive" hspace="2"></a></span>
            </div>
        </div>
    </div>
</div>


@include('includes.footer')


</body>
</html>