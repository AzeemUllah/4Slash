@include('includes.header')


<!-- content -->
  <div class="login-modal">
                    <h4 class="login-title">Kundenlogin</h4>

    <div class="modal-signin">
      <div class="container">
        <form method="post" action="{{ route('login') }}">

            @if($errors->has('others'))
            <div class="alert alert-danger" role="alert">{{ $errors->first('others') }}</div>
            @endif

            @if(\Illuminate\Support\Facades\Session::has('successMessage'))
                    <div class="alert alert-success" role="alert">{{ \Illuminate\Support\Facades\Session::get('successMessage') }}</div>
            @endif


            <div class="input form-group<?php echo $errors->has('email') ? ' has-error' : '' ?> input-new" style="positon:relative">
                <div class="email" style="margin: 0 auto;">
                  <label for="emailadress" class="sr-only">Email address</label>
                <span style="position:relative; top:35px; left:10px;">
                  <i class="fa fa-envelope-o"></i>
                 </span>
                <input value="{{ \Illuminate\Support\Facades\Input::old('email') }}" name="email" type="email" class="form-control em1" id="emailadress" placeholder="E-mail" style="height:50px; padding: 6px 45px;">
                    @if($errors->has('email'))
                        <p class="help-block">{{ $errors->first('email') }}</p>
                    @endif
                </div>

            </div>
            <div class="input form-group<?php echo $errors->has('password') ? ' has-error' : '' ?> input-new" style="positon:relative">
                <div class="password" style="margin: 0 auto;">
                  <label for="password" class="sr-only">Password</label>
                <span style="position:relative; top:40px; left:10px;">
                    <img src="img/lg-key.png" style="height:25px;">
                </span>
                <input name="password" type="password" class="form-control em2" id="password" placeholder="Passwort" style="height:50px; padding: 6px 45px;">
                    @if($errors->has('password'))
                        <p class="help-block">{{ $errors->first('password') }}</p>
                    @endif
                </div>
            </div>
            <div>
                <input type="hidden" name="type" value="user">
                <div class="send-box" style="margin: 0 auto;">
                    <div class="sig-btn">
                      <input type="checkbox"><span class="remember-css"angemeldet bleiben</span>
                        <input type="submit" class="btn btn-primary" value="einloggen">
                    </div>
                        <p class="forgt-pass"><a href="/password/email">Passwort vergessen?
</a></p>
                </div><!--send -->
            </div>       
            <div class="social-button text-center row" style="position:relative;">
                <div style="display:inline-block;float:none;" class="col-xs-12 col-sm-4 col-md-3 col-lg-4">
                    <div class="fb">
                        <a class="btn btn-block btn-social btn-facebook" style="box-shadow: 2px 3px 0px #0821A2">
                            <i class="fa fa-facebook"></i>
                            <span style="font-size: smaller;">Connect Facebook</span>
                        </a>
                    </div>
                </div>
                <div style="display:inline-block;float:none;" class="col-xs-12 col-sm-4 col-md-3 col-lg-4">
                    <div class="gm">
                        <a class="btn btn-block btn-social btn-google" style="box-shadow: 2px 3px 0px #770D00">
                            <i class="fa fa-google"></i>
                            <span style="font-size: smaller;">Connect Google</span>
                        </a>
                    </div>
                </div><!-- /.col-lg-6 -->
            </div><!-- /.row -->
        </form>
      </div>
    </div>
    <div class="modal-footer login-footer">
        <p class="footer-p">Neu registrieren? <a href="/register">Signup</a></p>
    </div>
  </div>


@include('includes.footer')

    </body>
</html>
