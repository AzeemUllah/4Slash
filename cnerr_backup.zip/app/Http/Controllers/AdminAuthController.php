<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use Illuminate\Support\Facades\Auth;
use Validator;
use Redirect;
use App\Http\Controllers\Controller;

class AdminAuthController extends Controller
{

    public function postLogin(Request $request) {


        $this->validate($request, [

            'email' => 'required|email|max:255',
            'password' => 'required|min:6',

        ]);

        if (Auth::admin()->attempt(['email' => $request->input('email'), 'password' => $request->input('password'), 'type' => 'admin'])) {
            return redirect()->route('admindashboard');
        }else {
            return Redirect::back()->withErrors(['auth' => 'Username and or Password is invalid.']);
        }


    }

    public function logout() {

        Auth::admin()->logout();

        return redirect()->route('adminlogin');

    }

}
