@include('includes.header')

<!--Content-->
   <div class="container top-gap">
   		<div class="well main">
        	<h1 class="text-primary">Packages</h1>
          
<!--collapse-->


<div class="accordion" id="accordion2">
  <?php $count = 1; ?>
  @foreach($packagesTypes as $packageType)
      <div class="accordion-group new-accordion">
    <div class="accordion-heading">
      <a class="accordion-toggle" data-toggle="collapse" data-parent="#package{{ $count }}" href="#package{{ $count }}">
        {{ $packageType->name }}
      </a>
    </div>
    <div id="package{{ $count }}" class="accordion-body collapse{{ (($count == 1)) ? ' in' : ''}}">
      <div class="accordion-inner">
        <div class="row">
          @foreach($packageType->packages as $package)
            <div class="col-sm-6 col-md-3 col-lg-3">
            <div class="thumbnail thum">
              <div class="ribbon-btn">
              <button type="button" class="btn btn-default" style="border-radius:30px; padding:2px 30px; text-align:center">{{ $package->title }}</button>
              </div>
              <div class="ribbon" style="background-image:url(img/ribbon2.png);">
                {{$package->price}}€
              </div>
              <div class="caption" style="margin-top:50px;">
                <ul>
                  @foreach($package->options as $option)
                    <li style="border-bottom:1px solid #dbdcdd;" class="bullt">
                      {{ $option->option }}
                    </li>
                  @endforeach
                </ul>
              </div>
              {{--<form method="post" action="{{ route('order.package') }}">--}}
                <div style="text-align:center;">
                  {{--<input type="hidden" name="package-id" value="{{ $package->packages_id }}">--}}
                  <a href="{{ route('order.package') }}?package-id={{ $package->packages_id }}"  type="submit" class="btn btn-primary">Purchase</a>
                </div>
              {{--</form>--}}
            </div>
          </div>
          @endforeach
        </div>
      </div>
    </div>
  </div>
    <?php $count++; ?>
  @endforeach
</div>			
    {{--<button type="button" class="btn btn-primary" style="margin-top:20px; padding:5px 40px; border-radius:10px;">Start</button>  --}}
  </div>
</div>


@include('includes.footer')





</body>
</html>
