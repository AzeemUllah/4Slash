<?php

namespace App\Http\Controllers;

use App\Gig;
use App\Order;
use App\Package;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class AdminOrdersController extends Controller
{
    public function index(Request $request)
    {
        $count_orders = 0;

        $user = Auth::admin()->get();


        $orders = Order::where(['gig_owner_id' => $user->id, 'status' => $request->input('status')])->get();


        if($request->input('status') == 'pending') {
            $count_orders = count($orders);
        }


        foreach($orders as $order) {
            $order['gig'] = Gig::where(['id' => $order->gig_id])->first();
        }

        $data['total_pending_orders'] = $count_orders;
        $data['orders'] = $orders;
        
        return view('pages.admin.orders')->with($data);
    }

    public function customOrders(Request $request) {

        $status = $request->input('status');

        $customOrders = Order::where(['type' => 'custom', 'status' => $status])->get();

        $data['customOrders'] = $customOrders;

        return view('pages.admin.customOrders')->with($data);

    }

    public function packagesOrders(Request $request) {

        $status = $request->input('status');

        $packagesOrders = Order::where(['type' => 'package', 'status' => $status])->get();

        if($packagesOrders->count() > 0) {
            foreach($packagesOrders as $packageOrder) {
                $packageOrder['package'] = Package::where(['packages_id' => $packageOrder->packages_id])->first();
            }
        }

        $data['packagesOrders'] = $packagesOrders;
       
        return view('pages.admin.packagesOrders')->with($data);

    }

}
