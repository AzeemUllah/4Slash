<?php

namespace App\Http\Controllers;

use App\Gig_question;
use App\Order;
use App\Gig;
use App\Package;
use App\User;
use App\Message;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Redirect;
use Intervention\Image\ImageManager;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\File;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

use Exception;

class MyOrdersController extends Controller
{
    private function askForOrderModification($orderNo)
    {
        $order = Order::where(['order_no' => $orderNo])->first();

        if(!is_object($order))
        {
            throw new RuntimeException("Something went wrong please try again later.");
        }

        $order->status = 'pending';
        $order->save();
    }

    public function index(Request $request)
    {
        $user = Auth::user()->get();

        $pendingOrders = Order::where(['user_id' => $user->id, 'status' => 'pending', 'type' => 'gig'])->orWhere(['user_id' => $user->id, 'status' => 'pending', 'type' => 'package'])->orWhere(['user_id' => $user->id, 'status' => 'jobdone', 'type' => 'gig'])->get();
        $completedOrders = Order::where(['user_id' => $user->id, 'status' => 'complete', 'type' => 'gig'])->orWhere(['user_id' => $user->id, 'status' => 'complete', 'type' => 'package'])->get();
        $customOrders = Order::where(['user_id' => $user->id, 'status' => 'pending', 'type' => 'custom'])->get();

        if(count($pendingOrders) > 0) {
            foreach ($pendingOrders as $order) {
                if($order->type == 'gig') {
                    $order['gig'] = Gig::where(['id' => $order->gig_id])->first();
                } else if($order->type == 'package') {
                    $order['package'] = Package::where(['packages_id' => $order->packages_id])->first();
                }
            }
        }

        if(count($completedOrders) > 0) {
            foreach ($completedOrders as $order) {
                if($order->type == 'gig') {
                    $order['gig'] = Gig::where(['id' => $order->gig_id])->first();
                } else if($order->type == 'package') {
                    $order['package'] = Package::where(['packages_id' => $order->packages_id])->first();
                }
            }
        }


        $data['pendingOrders'] = $pendingOrders;
        $data['completedOrders'] = $completedOrders;
        $data['customOrders'] = $customOrders;
        

        return view('pages.myorders')->with($data);
    }
    
    public function getMyOrder($orderno)
    {
        $user = Auth::user()->get();

        $order = Order::where(['user_id' => $user->id,'order_no' => $orderno])->first();

        $messages = Message::select('user_id', 'body')->where(['order_id' => $order->id, 'user_id' => $user->id])->orWhere(['order_id' => $order->id, 'to_id' => $user->id])->orderby('created_at', 'desc')->take(5)->get();
        $questions_answers = DB::table('order_questions_answers')->select('gig_question_id', 'answers')->where(['order_id' => $order->id])->get();

        foreach($questions_answers as $ques_ans) {
            $ques_ans->question = Gig_question::where(['id' => $ques_ans->gig_question_id])->first()->question;
            unset($ques_ans->gig_question_id);
        }

        foreach($messages as $message) {
            if($message->user_id == $user->id)
            {
                $message['from'] = 'me';
                $message['from_user_name_first_char'] = strtoupper($user->username[0]);
                $message['profile_image'] = $user->profile_image;
            }
            else if($message->to_id == $user->id)
            {
                $user = User::where(['id' => $order->gig_owner_id])->first();
                $message['from'] = 'him';
                $message['from_user_name_first_char'] = strtoupper($user->username[0]);
                $message['profile_image'] = $user->profile_image;
            }
            unset($message->user_id);
        }


        unset($order->gig_id);
        unset($order->gig_owner_id);
        unset($order->user_id);
        unset($order->id);

        $order['ques_ans'] = $questions_answers;
        $order['messages'] = $messages;

        return $order;

    }

    public function postMessage(Request $request)
    {
        $orderNo = $request->input('order-no');
        $txtMessage = $request->input('message');

        $user = Auth::user()->get();
        $order = Order::where(['order_no' => $orderNo])->first();

        $message = new Message();
        $message->body = $txtMessage;
        $message->order_id = $order->id;
        $message->user_id = $user->id;
        $message->to_id = $order->gig_owner_id;
        $message->save();

        return [
            'message' => $message->body
        ];
    }
    
    public function orderAcknowledge(Request $request)
    {
        $orderNo = $request->input('order-no');

        try {
            $order = Order::where(['order_no' => $orderNo])->first();
            $order->acknowledge();

            return Redirect::back();
        } catch (\Exception $e) {
            return Redirect::back()->withErrors(['msg' => 'Cannot acknowledge your order please try again.']);
        }
    }

    public function orderAskForModification(Request $request) {

        $orderNo = $request->input('order-no');

        if($request->ajax())
        {
            try
            {
                $this->askForOrderModification($orderNo);

                return ['status' => true, 'msg' => 'Order successfully submitted for modification.'];
            }
            catch(\Exception $e)
            {
                return ['status' => false, 'msg' => $e];
            }
        }

        try
        {
            $this->askForOrderModification($orderNo);

            return Redirect::back();
        }
        catch(\Exception $e)
        {
            return Redirect::back()->withErrors(['msg' => $e]);
        }

    }

}
