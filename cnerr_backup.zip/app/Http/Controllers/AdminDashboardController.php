<?php

namespace App\Http\Controllers;

use App\Admin;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\User;
use App\Order;
use Illuminate\Support\Facades\Auth;

class AdminDashboardController extends Controller
{

    public function index(Request $request)
    {
        $user = Auth::admin()->get();

        $data['wallet'] = Admin::where(['id' => $user->id])->first()->wallet;
        $data['totalUser'] = Admin::where(['type' => 'user'])->count();
        $data['totalNewOrders'] = Order::where(['status' => 'penidng'])->count();
        
        return view('pages.admin.dashboard')->with($data);
    }


}
