@include('includes.header')

<!-- Content -->
        <div class="notify-main-content top-gap">
            <div class="container">
                <div class="well">
                    <h1 style="padding:34px 52px;">Meine Zahlungen</h1>




    <div class="upper-pay">
        <div class="well pay-box" style="background-color:white;">
            <div class="row text-center pay-sect">
                <div class="col-xs-4">
                <h1 class="upper">{{ config('app.currency') }}0</h1>
                <h1 style="color:black; font-size:14px;">verfügbar Geld</h1>
                </div>
                <div class="col-xs-4">
                <h1 class="upper">{{ config('app.currency') . $pendingOrdersAmount }}</h1>
                <h1 style="color:black; font-size:14px;">aktuelle Bestellungen</h1>
                </div>
                <div class="col-xs-4">
                <h1 class="upper">{{ config('app.currency') . $completedOrdersAmount }}</h1>
                <h1 style="color:black; font-size:14px;">fertige Aufträge</h1>
                </div>
            </div>
        </div>
    </div>




						<div class="row upper-pay">
                        
                            <div class="col-md-1 col-sm-1 col-xs-1 selec-opt">
                                <p>schau</p>
                            </div>
                            <div class="col-md-2 col-sm-2 col-xs-2">
						 	<select class="form-control">
                                <option>All</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                            </select>
							</div>
                            <div class="col-md-2 col-sm-2 col-xs-2 selec-opt">
                                <p>Überweisungen</p>
                            </div>               
                            
                            </div>
                            
    
    <div class="upper-pay">
        <div class="table-content">
        <table class="table table-striped new table-payment-transactions">
    <thead>
      <tr>
        <th>Datum</th>
        <th>Beschreibung</th>
        <th style="text-align:right;">Summe</th>
      </tr>
    </thead>
    <tbody>
        @if(count($completedOrders) > 0)
            @foreach($completedOrders as $completedOrder)
              <tr>
                  <td>{{ date("M d, Y", strtotime($completedOrder->updated_at)) }}</td>
                  <td>{{ $completedOrder->gig->title }} <a href="{{ route('orderinvoice', ['orderno' => $completedOrder->order_no, 'invoiceno' => $completedOrder->invoice->invoice_no]) }}">(Rechnung)</a></td>
                  <td style="text-align:right; color:#33a5dd">{{ config('app.currency') . $completedOrder->amount }}</td>
              </tr>
            @endforeach
        @endif
      
      {{--<tr>--}}
        {{--<td class="text-center" colspan="3">You have no transactions.</td>--}}
        {{----}}
      {{--</tr>--}}
      
    </tbody>
  </table>
    </div>
    </div>





</div>

 						
                            
                             
 
 
 
 
 
 
 
 
 
 
        
</div>
</div>




      
       





           </div>
        </div>



 @include('includes.footer')

      
    </body>
</html>