<?php

namespace App\Http\Controllers;

use App\PackageType;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Auth;



class AdminPackagesTypesController extends Controller
{
    public function index()
    {
        $packagesTypes = PackageType::all();

        $data['packagesTypes'] = $packagesTypes;

        return view('pages.admin.packages_types')->with($data);
    }

    public function create(Request $request)
    {
        if(isset($_POST['package-submit']))
        {
            PackageType::create(['name' => $request->input('package-name')]);
        }

        return view('pages.admin.packages_types_create');
    }

    public function delete(Request $request)
    {
        $totalpackagedeleted = PackageType::destroy($request->input('package-type-id'));

        if($totalpackagedeleted > 0)
        {
            return ['deleted' => true];
        }
        else
        {
            return ['deleted' => false];
        }
    }
}