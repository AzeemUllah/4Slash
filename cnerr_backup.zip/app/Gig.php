<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class Gig extends Model
{

    protected $fillable = [
        'uuid',
        'gigtype_id',
        'user_id',
        'slug',
        'title',
        'short_discription',
        'discription',
        'delivery_days',
        'price',
    ];

    /**
     * @param array
     *      $gigDataAssocArray['gig']['id']
     *      $gigDataAssocArray['gig']['gig-category-id']
     *      $gigDataAssocArray['gig']['gig-slug']
     *      $gigDataAssocArray['gig']['gig-title']
     *      $gigDataAssocArray['gig']['gig-short-discription']
     *      $gigDataAssocArray['gig']['gig-discription']
     *      $gigDataAssocArray['gig']['gig-delivery-days']
     *      $gigDataAssocArray['gig']['gig-price']
     * @return bool
     *      true = updated successfully
     *      false = updating failed
     */
    public static function gigUpdate($gigDataAssocArray, $request) {

        try {

            DB::transaction(function () use ($gigDataAssocArray, $request) {

                $gig = self::find($gigDataAssocArray['gig']['id']);
                $gig->gigtype_id = $gigDataAssocArray['gig']['gig-category-id'];
                $gig->gigtypes_subcategories_id = $gigDataAssocArray['gig']['gig-sub-category-id'];
                $gig->slug = str_replace(' ', '_', strtolower($gigDataAssocArray['gig']['gig-slug']));
                $gig->title = $gigDataAssocArray['gig']['gig-title'];
                $gig->short_discription = $gigDataAssocArray['gig']['gig-short-discription'];
                $gig->discription = $gigDataAssocArray['gig']['gig-discription'];
                $gig->delivery_days = $gigDataAssocArray['gig']['gig-delivery-days'];
                $gig->price = $gigDataAssocArray['gig']['gig-price'];
                $gig->save();

                Gig_question::where(['gig_id' => $gig->id])->delete();

                if (count($request->input('gig-choice-question')) > 0) {
                    foreach ($request->input('gig-choice-question') as $gig_choice_quest) {
                        Gig_question::create([
                            'gig_id' => $gig->id,
                            'question' => $gig_choice_quest['question'],
                            'answers' => implode(',', $gig_choice_quest['answers']),
                            'type' => 'check',
                        ]);
                    }
                }

            });

            return true;


        } catch(\Exception $e) {
            return false;
        }

    }

    /**
     * @param int $gigId
     * @return int 0|1 notActivated|Activated
     */
    public static function gigActivate($gigId) {
        $gig = self::find($gigId);

        if($gig->active) {
            $gig->active = 0;
        } else {
            $gig->active = 1;
        }

        $gig->save();

        return $gig->active;
    }

    /**
     * @param int $gigId
     * @return int 0|1 notFeatured|Featured
     */
    public static function gigFeatured($gigId) {
        $gig = self::find($gigId);

        if($gig->featured) {
            $gig->featured = 0;
        } else {
            $gig->featured = 1;
        }

        $gig->save();

        return $gig->featured;
    }

    public static function getAllGigs() {
        return self::where(['active' => 1])->orderBy('featured', 'desc')->take(9)->get();
    }

    public static function getAllFeaturedGigs() {
        return self::where(['active' => 1, 'featured' => 1])->get();
    }

//    public static function favourite($gigUUID = 0) {
//
//        if(Auth::user()->check()) {
//            $gig = Gig::where(['uuid' => $gigUUID])->first();
//            $loggedInUser = Auth::user()->get();
//
//            $favouriteGig = FavouriteGigs::where(['user_id' => $loggedInUser->id, 'gig_id' => $gig->id])->first();
//
//            if (is_object($favouriteGig)) {
//
//                $favouriteDelete = $favouriteGig->delete();
//                if ($favouriteDelete) {
//                    $success = false;
//                }
//
//            } else {
//
//                $newFavouriteGig = new FavouriteGigs();
//                $newFavouriteGig->user_id = $loggedInUser->id;
//                $newFavouriteGig->gig_id = $gig->id;
//                $favouriteSaved = $newFavouriteGig->save();
//
//                if ($favouriteSaved) {
//                    $success = true;
//                }
//
//            }
//
//            return $success;
//        }
//
//        return false;
//
//
//    }

}
