<?php

namespace App\Http\Controllers;

use App\Package;
use App\PackageOption;
use App\PackageType;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AdminPackagesController extends Controller
{
    public function index()
    {
        $packages = Package::all();

        foreach($packages as $package) {
            $package->type = PackageType::where(['id' => $package->packages_types_id])->first();
        }

        $data['packages'] = $packages;

        return view('pages.admin.packages')->with($data);
    }

    public function create(Request $request)
    {

        if(isset($_POST['create-package']))
        {
            $packageTypeId = $request->input('package-type');
            $packageTitle = $request->input('package-title');
            $packagePrice = $request->input('package-price');
            $packageOptions = $request->input('package-option');


            try {

                DB::transaction(function () use ($packageTypeId, $packageTitle, $packagePrice, $packageOptions) {

                    $package = Package::create([
                        'packages_id' => uniqid(),
                        'title' => $packageTitle,
                        'price' => $packagePrice,
                        'packages_types_id' => $packageTypeId
                    ]);

                    foreach ($packageOptions as $packageOption) {
                        PackageOption::create([
                            'option' => $packageOption,
                            'packages_id' => $package->id
                        ]);
                    }

                });

                return redirect()->route('adminpackages');
            } catch(\Exception $e) {
                dd($e);
            }
        }


        $packagesTypes = PackageType::all();

        $data['packagestypes'] = $packagesTypes;

        return view('pages.admin.packages_create')->with($data);
    }
}