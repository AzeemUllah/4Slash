<?php

namespace App\Http\Controllers;

use App\Package;
use App\PackageOption;
use App\PackageType;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class PackagesController extends Controller
{
    public function index() {

        $packageTypes = PackageType::all();

        foreach($packageTypes as $packageType)
        {
            $packageType->packages = Package::where(['packages_types_id' => $packageType->id])->get();

            foreach($packageType->packages as $package)
            {
                $package->options = PackageOption::where(['packages_id' => $package->id])->get();
            }
        }

        $data['packagesTypes'] = $packageTypes;

        return view('pages.packages')->with($data);
    }
}