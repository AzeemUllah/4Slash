<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Stripe, Mailgun, Mandrill, and others. This file provides a sane
    | default location for this type of information, allowing packages
    | to have a conventional place to find your various credentials.
    |
    */

    'mailgun' => [
        'domain' => '',
        'secret' => '',
    ],

    'mandrill' => [
        'secret' => '',
    ],

    'ses' => [
        'key'    => '',
        'secret' => '',
        'region' => 'us-east-1',
    ],

    'stripe' => [
        'model'  => App\User::class,
        'key'    => '',
        'secret' => '',
    ],

    'google' => [
        'client_id' => '747977863578-kd078kmrnu9o745sosh2a61eao178nk2.apps.googleusercontent.com',
        'client_secret' => 'qcAk3a7ai6dWbnO_zGdHLaNb',
        'redirect' => 'http://localhost:8000/google_callback',
    ],

    'facebook' => [

    ]

];
