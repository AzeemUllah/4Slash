<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Message extends Model
{
    protected $table = 'messages';
    protected static $instance = null;

    protected $fillable = [
        'order_id',
        'user_id',
        'to_id',
        'body',
    ];

    public static function getInstance()
    {
        if(is_null(self::$instance))
            self::$instance = new self();

        return self::$instance;
    }

    public static function sendMessage($request, $user, $orderuuid = null, $from)
    {

        if ($request->hasFile('file-attachment'))
        {
            if ($request->file('file-attachment')->isValid())
            {
                $file = $request->file('file-attachment')->move(public_path() . '/files/orders/messages', rand(0, 1000) . 'ok' . time() . '.' . $request->file('file-attachment')->getClientOriginalExtension());
                $file_url = '<a target="_blank" href="'. url() . '/files/orders/messages/' . $file->getFilename() .'">'. $request->file('file-attachment')->getClientOriginalName() .'</a>';
            }
        }

        $orderuuid = ($orderuuid) ? $orderuuid : $request->input('orderuuid');
        $order = Order::where(['uuid' => $orderuuid])->first();

        $message = $request->input('message') . (isset($file_url) ? '<br>' . $file_url : '');

        $messageInstance = self::getInstance();
        $messageInstance->order_id = $order->id;
        $messageInstance->user_id = $user->id;
        if($request->input('receiver')) {
            if($request->input('receiver') == 'client') {
                $messageInstance->to_id = $order->user_id;
            } else if($request->input('receiver') == 'agency') {
                $messageInstance->to_id = $order->assigned_to;
            }
        }
        $messageInstance->body = $message;
        $saved = $messageInstance->save();


        if($saved) {
//            Notification::sendNotification($order->gig_owner_id, '<i class="fa fa-envelope"></i> You have a new message from ' . (($from == 'Cnerr') ? $from : $from . ' ' . $user->username));

            return $messageInstance;
        } else {
            return false;
        }
    }
}
