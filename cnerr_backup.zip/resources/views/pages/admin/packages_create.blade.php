@extends('pages.admin.admin_template')


@section('header_title')

    <h1>Create a new Package</h1>

@endsection




@section('content')

    <form method="post" enctype="multipart/form-data">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-info">

                    <div class="box-body">



                        <!-- select -->
                        <div class="row">
                            <div class="col-md-6 form-group">
                                <label>Package Type</label>
                                <select name="package-type" class="form-control">
                                    @foreach($packagestypes as $packagestype)
                                        <option value="{{ $packagestype->id }}">{{ $packagestype->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>


                        <!-- text input -->
                        <div class="row">
                            <div class="col-md-6 form-group">
                                <label>Title</label>
                                <input name="package-title" type="text"
                                       class="form-control" placeholder="Enter Package Title...">
                            </div>
                        </div>


                        <!-- select -->
                        <div class="row">

                            <div class="col-md-6 form-group">
                                <label>Price</label>

                                <div class="input-group">
                                    <span class="input-group-addon">&euro;</span>
                                    <input name="package-price" type="number"
                                           class="form-control">
                                    <span class="input-group-addon">.00</span>
                                </div>
                            </div>

                        </div>


                        <label>Options</label>
                        <div class="row">
                            <div class="col-md-2 form-group">

                                <input name="package-option[]" type="text" class="form-control" placeholder="Enter Option...">
                            </div>
                            <div class="col-md-2 form-group">
                                <input id="btnAddMoreOption" type="button" class="form-control btn btn-primary" value="Add More Option">
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>






        <div class="text-center">
                <button name="create-package" class="btn btn-primary btn-lg" type="submit">Create</button>
        </div>
    </form>

@endsection



@section('pages_css')


@endsection



@section('pages_script')

    <script>
        (function() {
            $('#btnAddMoreOption').click(function(e) {
                var option = '<div class="col-md-2 form-group"><input name="package-option[]" type="text" class="form-control" placeholder="Enter Option..."></div>';
                $(option).insertBefore($(this).parent());
            });
        })();
    </script>


@endsection