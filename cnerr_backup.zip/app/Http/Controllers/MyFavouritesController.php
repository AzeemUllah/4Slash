<?php

namespace App\Http\Controllers;

use App\FavouriteGigs;
use App\Gigtype;
use App\GigImages;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Gig;
use Illuminate\Support\Facades\Auth;

class MyFavouritesController extends Controller
{

    public function index(Request $request)
    {
        $loggedInUser = Auth::user()->get();
        // getting favourite gigs by user id and assign to a variable
        $myFavourites = FavouriteGigs::where(['user_id' => $loggedInUser->id])->get();

        $gigs = [];


        if (count($myFavourites) > 0) {

            foreach ($myFavourites as $myFavourite) {

                $gig = Gig::where(['id' => $myFavourite->gig_id])->first();

                if (is_object($gig)) {

                    if(is_object($gigType = Gigtype::where(['id' => $gig->gigtype_id])->first())) {

                        $gig['gigType'] = $gigType;
                        $gig['thumbnail'] = GigImages::getGigThumbnail($gig->id);

                        array_push($gigs, $gig);

                    }
                    else {

                        continue;

                    }

                } else {

                    continue;

                }

            }

        }


        // assign myfavourite gigs variable to data variable to send to the view
        $data['myFavouriteGigs'] = $gigs;

        // returning the favourite view page.
        return view('pages.favourites')->with($data);
    }

}
