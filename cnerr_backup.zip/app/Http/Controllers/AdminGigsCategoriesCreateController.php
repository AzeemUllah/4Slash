<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers;
use App\Gigtype;

class AdminGigsCategoriesCreateController extends Controller
{
    public function index()
    {
        return view('pages.admin.gigs_categories_create');
    }

    public function create(Request $request)
    {
        $gigCategory = new Gigtype();
        $gigCategory->slug = str_replace(' ', '_', strtolower($request->input('gigcategory-name')));
        $gigCategory->name = $request->input('gigcategory-name');
        if($gigCategory->save())
        {
            return redirect()->route('admingigscategoriescreate');
        }
        else
        {
            return redirect()->route('admingigscategoriescreate')->withErrors(['msg' => 'cannot create new category right now please try later.']);
        }


    }

    public function delete(Request $request) {
        $gigDelete = Gigtype::destroy($request->input('gig-category-id'));


        if($gigDelete > 0)
        {
            return ['deleted' => true];
        }
        else
        {
            return ['deleted' => false];
        }
    }
}