
@include('includes.header')

        <!-- content -->
    <div class="container">
        <div class="row" style="margin-top: 65px; margin-bottom: 60px;">

            <div class="col-xs-6 col-xs-push-3" style="text-align:-webkit-center;">
                    <form method="POST" action="/password/email">
                        {!! csrf_field() !!}


                        @if (count($errors) > 0)
                            @foreach ($errors->all() as $error)
                                <div class="alert alert-danger alert-dismissible" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    {{ $error }}
                                </div>
                            @endforeach
                        @endif

                        @if (session('status'))
                            <div class="alert alert-success alert-dismissible" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                {{ session('status') }}
                            </div>
                        @endif




                        <div class="form-group">
                            <label for="email"></label>
                            <input type="email" name="email" class="form-control" id="email" placeholder="jane.doe@example.com" value="{{ old('email') }}">
                        </div>
                        <button type="submit" class="btn btn-primary">
                            Send Password Reset Link
                        </button>

                    </form>
                {{--<button type="button" class="btn btn-primary"><span class="glyphicon glyphicon-th-large" style="margin-right:5px;"></span>View all Gigs</button>--}}
            </div>
        </div>
    </div>



@include('includes.footer')


</body>
</html>
